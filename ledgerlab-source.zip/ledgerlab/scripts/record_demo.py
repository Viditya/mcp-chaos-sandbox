from __future__ import annotations

import os
import re
from pathlib import Path

from playwright.sync_api import expect, sync_playwright


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "evidence" / "ledgerlab-silent-demo.webm"


def dashboard_token() -> str:
    for line in (ROOT / ".env").read_text().splitlines():
        if line.startswith("CHAOS_DASHBOARD_TOKEN="):
            return line.split("=", 1)[1]
    raise RuntimeError("CHAOS_DASHBOARD_TOKEN is missing from .env")


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists():
        OUTPUT.unlink()

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False)
        context = browser.new_context(
            viewport={"width": 1280, "height": 720},
            record_video_dir=str(OUTPUT.parent),
            record_video_size={"width": 1280, "height": 720},
        )
        page = context.new_page()
        page.goto("http://127.0.0.1:8080/", wait_until="networkidle")

        token_field = page.get_by_label("Dashboard access token", exact=True)
        if token_field.is_visible():
            token_field.fill(dashboard_token())
            page.get_by_role("button", name="Open workspace").click()
            page.get_by_role("heading", name="Reconciliation lab.").wait_for()

        # Opening: establish the workload and genuine $50 exception.
        page.get_by_role("heading", name="A ledger with one exception").scroll_into_view_if_needed()
        page.wait_for_timeout(12_000)

        # Run the complete deterministic validation batch.
        page.get_by_label("Execution engine", exact=True).select_option(label="Scripted · local validation only")
        run_all = page.get_by_role("button", name=re.compile(r"Run all"))
        run_all.scroll_into_view_if_needed()
        page.wait_for_timeout(3_000)
        run_all.click()
        expect(run_all).to_be_enabled(timeout=120_000)
        page.wait_for_timeout(5_000)

        # Show the wrong-total recovery and its independently verified report.
        wrong_total = page.get_by_role("button", name=re.compile(r"^Plausible wrong total")).first
        wrong_total.scroll_into_view_if_needed()
        wrong_total.click()
        page.wait_for_timeout(12_000)

        # Finish on the safe-halt proof for persistent outage.
        outage = page.get_by_role("button", name=re.compile(r"^Persistent outage")).first
        outage.scroll_into_view_if_needed()
        outage.click()
        page.get_by_text("Execution stopped safely").scroll_into_view_if_needed()
        page.wait_for_timeout(15_000)

        video = page.video
        page.close()
        context.close()
        video.save_as(str(OUTPUT))
        browser.close()

    print(f"Recorded silent demo: {OUTPUT}")


if __name__ == "__main__":
    os.chdir(ROOT)
    main()
