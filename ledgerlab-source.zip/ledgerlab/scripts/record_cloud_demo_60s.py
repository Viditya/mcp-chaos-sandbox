from __future__ import annotations

import re
import subprocess
from pathlib import Path

from playwright.sync_api import expect, sync_playwright


ROOT = Path(__file__).resolve().parents[1]
URL = "https://8080-001m600n1w0e32m0h6wkcbs5rkt.sbx.sandboxes-cloud.docker.com/"
OUTPUT = ROOT / "evidence" / "ledgerlab-docker-cloud-60s.webm"


def cloud_token() -> str:
    result = subprocess.run(
        [
            "sbx",
            "--cloud",
            "exec",
            "ledgerlab-mvp",
            "cat",
            "/home/agent/workspace/ledgerlab/.env",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    for line in result.stdout.splitlines():
        if line.startswith("CHAOS_DASHBOARD_TOKEN="):
            return line.split("=", 1)[1]
    raise RuntimeError("Cloud dashboard token was not returned")


def install_director_ui(page) -> None:
    page.evaluate(
        """
        () => {
          const style = document.createElement('style');
          style.textContent = `
            .demo-focus { position: relative; z-index: 20; outline: 3px solid #f59e0b !important;
              box-shadow: 0 0 0 7px rgba(245,158,11,.18), 0 15px 45px rgba(15,23,42,.18) !important;
              transition: all .35s ease !important; }
            #demo-cue { position: fixed; left: 50%; bottom: 18px; transform: translateX(-50%);
              z-index: 999999; width: min(760px, 90vw); padding: 11px 16px; border-radius: 9px;
              background: rgba(15,23,42,.92); color: #f8fafc; text-align: center;
              font: 600 14px/1.4 system-ui, sans-serif; box-shadow: 0 12px 35px rgba(0,0,0,.28);
              border: 1px solid rgba(255,255,255,.14); transition: opacity .25s ease; }
            #demo-cue small { display:block; margin-top:3px; color:#94a3b8; font-size:11px; font-weight:500; }
          `;
          document.head.appendChild(style);
          const cue = document.createElement('div');
          cue.id = 'demo-cue';
          document.body.appendChild(cue);
        }
        """
    )


def cue(page, title: str, detail: str) -> None:
    page.locator("#demo-cue").evaluate(
        "(el, value) => { el.innerHTML = `<strong>${value[0]}</strong><small>${value[1]}</small>`; }",
        [title, detail],
    )


def focus(page, locator) -> None:
    page.locator(".demo-focus").evaluate_all("els => els.forEach(el => el.classList.remove('demo-focus'))")
    locator.evaluate("el => { el.scrollIntoView({behavior:'smooth', block:'center'}); el.classList.add('demo-focus'); }")
    page.wait_for_timeout(700)


def run_scenario(page, label: str, expected_status: str):
    page.get_by_label("Fault scenario", exact=True).select_option(label=label)
    rows = page.locator(".run-list .run-row")
    previous_count = rows.count()
    run_button = page.get_by_role("button", name=re.compile(r"^Run experiment"))
    run_button.click()
    expect(rows).to_have_count(previous_count + 1, timeout=30_000)
    newest = rows.first
    expect(newest).to_contain_text(expected_status, timeout=120_000)
    newest.click()
    return newest


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists():
        OUTPUT.unlink()

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False)
        context = browser.new_context(
            viewport={"width": 1280, "height": 720},
            record_video_dir=str(OUTPUT.parent),
            record_video_size={"width": 1280, "height": 720},
        )
        page = context.new_page()
        page.goto(URL, wait_until="networkidle", timeout=60_000)

        token_field = page.get_by_label("Dashboard access token", exact=True)
        if token_field.is_visible():
            token_field.fill(cloud_token())
            page.get_by_role("button", name="Open workspace").click()

        page.get_by_role("heading", name="Reconciliation lab.").wait_for(timeout=30_000)
        expect(page.locator(".environment")).to_contain_text(re.compile(r"docker.cloud", re.I))
        install_director_ui(page)

        cue(page, "LedgerLab on Docker Cloud", "Scripted validation of an immutable synthetic ledger")
        focus(page, page.locator(".environment"))
        page.wait_for_timeout(3_000)

        workload = page.locator(".fixture-panel")
        cue(page, "One genuine business discrepancy", "Order B: $200 expected, $150 captured — $50 underpaid")
        focus(page, workload)
        page.wait_for_timeout(4_000)

        page.get_by_label("Execution engine", exact=True).select_option(label="Scripted · local validation only")

        cue(page, "Plausible wrong total", "Reported captured total: $600 · immutable raw rows: $550")
        focus(page, page.locator(".setup-panel"))
        run_scenario(page, "Plausible wrong total", "Recovered")
        report = page.locator(".report")
        focus(page, report)
        cue(page, "Recovered from the false summary", "After the $50 settled refund: expected $550 · received $500 · difference $50")
        page.wait_for_timeout(4_000)
        inconsistency = page.get_by_text(
            "Payment summary disagrees with independent raw ledger rows; recomputing.", exact=True
        )
        focus(page, inconsistency)
        cue(page, "Independent recomputation", "The workflow rejected $600 and used complete raw payment rows")
        page.wait_for_timeout(4_000)

        cue(page, "Transient timeout", "The same payment read is retried once, then verification continues")
        focus(page, page.locator(".setup-panel"))
        run_scenario(page, "Transient timeout", "Recovered")
        retry_event = page.get_by_text(
            "Retrying read_payments once after invalid or unavailable response.", exact=True
        )
        focus(page, retry_event)
        page.wait_for_timeout(4_000)

        cue(page, "Persistent outage", "Two bounded failures produce a safe halt — never an unverified report")
        focus(page, page.locator(".setup-panel"))
        run_scenario(page, "Persistent outage", "Safe halt")
        stopped = page.locator(".run-error")
        focus(page, stopped)
        page.wait_for_timeout(5_000)

        page.evaluate("window.scrollTo({top: 0, behavior: 'smooth'})")
        cue(page, "5/5 expected outcomes validated", "Docker Cloud · verified recoveries plus the expected bounded safe halt")
        focus(page, page.locator(".environment"))
        page.wait_for_timeout(5_000)

        video = page.video
        page.close()
        context.close()
        video.save_as(str(OUTPUT))
        browser.close()

    print(f"Recorded fast Docker Cloud demo: {OUTPUT}")


if __name__ == "__main__":
    main()
