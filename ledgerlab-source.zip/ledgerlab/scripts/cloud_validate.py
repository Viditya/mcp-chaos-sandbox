"""Private HTTP acceptance suite; never emits credentials or provider diagnostics."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import httpx

from chaos_reconcile.domain import expected_report

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {"clean": "completed", "timeout_once": "recovered", "truncated_once": "recovered", "wrong_total_once": "recovered", "persistent_timeout": "halted"}


def main() -> None:
    token = os.environ.get("CHAOS_DASHBOARD_TOKEN")
    if not token:
        token = next(line.split("=", 1)[1] for line in (ROOT / ".env").read_text().splitlines() if line.startswith("CHAOS_DASHBOARD_TOKEN="))
    with httpx.Client(base_url="http://127.0.0.1:8080", trust_env=False, timeout=10) as client:
        assert client.get("/api/health").status_code == 200
        assert client.get("/api/runs").status_code == 401
        headers = {"Authorization": f"Bearer {token}"}
        body = {"mode": "codex", "idempotency_key": "cloud-acceptance-suite-v1"}
        response = client.post("/api/suite", json=body, headers=headers)
        response.raise_for_status()
        runs = response.json()["runs"]
        replay = client.post("/api/suite", json=body, headers=headers)
        replay.raise_for_status()
        assert [r["id"] for r in replay.json()["runs"]] == [r["id"] for r in runs]
        print("Authenticated private API; suite replay reused all run IDs.", flush=True)
        pending = {r["id"] for r in runs}
        seen = {}
        deadline = time.monotonic() + 930
        while pending and time.monotonic() < deadline:
            for run_id in list(pending):
                current = client.get(f"/api/runs/{run_id}", headers=headers)
                current.raise_for_status()
                run = current.json()
                if seen.get(run_id) != run["status"]:
                    print(json.dumps({"scenario": run["scenario"], "status": run["status"]}), flush=True)
                    seen[run_id] = run["status"]
                if run["status"] in {"completed", "recovered", "halted", "failed"}:
                    pending.remove(run_id)
            if pending:
                time.sleep(1)
        if pending:
            raise RuntimeError("Acceptance suite did not finish before its deadline")
        results = []
        for run in runs:
            export = client.get(f"/api/runs/{run['id']}/export", headers=headers)
            export.raise_for_status()
            result = export.json()
            final = result["run"]
            if final["status"] in {"completed", "recovered"}:
                assert final["report"] == expected_report()
            else:
                assert final["report"] is None
            results.append(result)
        output = {"mode": "codex", "environment": "docker-cloud", "suite": "cloud-acceptance-suite-v1", "runs": results}
        path = ROOT / "evidence/cloud-codex-suite.json"
        path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps(output, indent=2))
        summary = [{"scenario": r["run"]["scenario"], "status": r["run"]["status"], "calls": r["run"]["tool_calls"], "faults": r["run"]["fault_count"]} for r in results]
        print(json.dumps({"results": summary, "output": str(path)}), flush=True)
        assert all(r["run"]["status"] == EXPECTED[r["run"]["scenario"]] for r in results), "Unexpected scenario outcome; inspect persisted evidence"


if __name__ == "__main__":
    main()
