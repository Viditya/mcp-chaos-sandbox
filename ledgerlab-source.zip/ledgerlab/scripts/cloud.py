#!/usr/bin/env python3
"""Private bounded deployment. No credential uploads or public port publication."""
from __future__ import annotations

import argparse
import json
import subprocess
import tarfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAME = "ledgerlab-mvp"
REMOTE = "/home/agent/workspace/ledgerlab"


def sbx(*args: str) -> str:
    result = subprocess.run(["sbx", "--cloud", *args], text=True, capture_output=True, timeout=180)
    if result.stderr:
        print(result.stderr.strip())
    if result.returncode:
        raise RuntimeError(f"sbx {args[0]} failed: {result.stdout.strip()}")
    return result.stdout


def deploy() -> None:
    runtime = ROOT / "runtime"
    runtime.mkdir(exist_ok=True)
    if not (ROOT / "frontend/dist/index.html").exists():
        raise SystemExit("Build frontend first: cd frontend && npm ci && npm run build")
    archive = runtime / "deploy.tar.gz"
    with tarfile.open(archive, "w:gz") as bundle:
        for entry in ("pyproject.toml", "uv.lock", ".python-version", "src", "tests", "scripts", "README.md", "frontend/dist"):
            bundle.add(ROOT / entry, arcname=entry, filter=lambda item: None if "__pycache__" in item.name else item)
    print(sbx("ttl", NAME).strip())
    preflight = f"""from pathlib import Path
import os,sqlite3
p=Path({REMOTE!r})
pid=p/'runtime/server.pid'
if pid.exists():
    try:
        os.kill(int(pid.read_text()),0)
        raise SystemExit('Existing application is running; stop it before replacing source.')
    except ProcessLookupError:
        pass
"""
    sbx("exec", NAME, "python3", "-c", preflight)
    print(sbx("cp", str(archive), f"{NAME}:/tmp/ledgerlab-deploy.tar.gz").strip())
    unpack = f"import tarfile; from pathlib import Path; p=Path({REMOTE!r}); p.mkdir(parents=True,exist_ok=True); tarfile.open('/tmp/ledgerlab-deploy.tar.gz').extractall(p,filter='data')"
    sbx("exec", NAME, "python3", "-c", unpack)
    print(sbx("exec", "-w", REMOTE, NAME, "uv", "sync", "--locked").strip())
    # Generate a fresh dashboard credential INSIDE the sandbox. No secret is copied from this machine.
    print(sbx("exec", "-w", REMOTE, NAME, "uv", "run", "ledgerlab", "init").strip())
    launcher = f"""import os,subprocess
from pathlib import Path
p=Path({REMOTE!r}); (p/'runtime').mkdir(exist_ok=True)
pidfile=p/'runtime/server.pid'
if pidfile.exists():
    try:
        os.kill(int(pidfile.read_text()),0)
        raise SystemExit('Server already running; stop it before redeploying.')
    except ProcessLookupError:
        pass
env=os.environ.copy(); env.update(LEDGERLAB_ENVIRONMENT='docker-cloud',CHAOS_COOKIE_SECURE='1',LEDGERLAB_MAX_CODEX_RUNS='12')
log=(p/'runtime/server.log').open('a')
proc=subprocess.Popen([str(p/'.venv/bin/ledgerlab'),'serve','--host','0.0.0.0','--port','8080'],cwd=p,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
pidfile.write_text(str(proc.pid))
print('Private application started, pid',proc.pid)
"""
    print(sbx("exec", NAME, "python3", "-c", launcher).strip())
    metadata = {"sandbox": NAME, "deployed_at": datetime.now(UTC).isoformat(),
                "remote_path": REMOTE, "authorized_budget_usd": 10, "ttl_at_creation": "30m", "on_timeout": "stop",
                "public_endpoint": None, "credential_transfer": "none; generated inside cloud",
                "billing_note": "Actual compute charges are reported by Docker; OAuth usage consumes the user's Codex plan allowance."}
    (ROOT / "evidence").mkdir(exist_ok=True)
    (ROOT / "evidence/deployment.json").write_text(json.dumps(metadata, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["deploy", "status", "export", "stop"])
    args = parser.parse_args()
    if args.command == "deploy":
        deploy()
    elif args.command == "status":
        print(sbx("ls"))
        print(sbx("ttl", NAME))
        print(sbx("ports", NAME))
    elif args.command == "export":
        (ROOT / "evidence").mkdir(exist_ok=True)
        backup = f"import sqlite3; c=sqlite3.connect('{REMOTE}/runtime/ledgerlab.sqlite3'); out=sqlite3.connect('/tmp/ledgerlab-backup.sqlite3'); c.backup(out); out.close(); c.close()"
        sbx("exec", NAME, "python3", "-c", backup)
        print(sbx("cp", f"{NAME}:/tmp/ledgerlab-backup.sqlite3", str(ROOT / "evidence/cloud-ledger.sqlite3")))
    else:
        print(sbx("stop", NAME))


if __name__ == "__main__":
    main()
