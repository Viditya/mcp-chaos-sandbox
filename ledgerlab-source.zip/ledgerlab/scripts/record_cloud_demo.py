from __future__ import annotations

import re
import subprocess
from pathlib import Path

from playwright.sync_api import expect, sync_playwright


ROOT = Path(__file__).resolve().parents[1]
URL = "https://8080-001m600n1w0e32m0h6wkcbs5rkt.sbx.sandboxes-cloud.docker.com/"
OUTPUT = ROOT / "evidence" / "ledgerlab-docker-cloud-silent-demo.webm"


def cloud_token() -> str:
    completed = subprocess.run(
        [
            "sbx",
            "--cloud",
            "exec",
            "ledgerlab-mvp",
            "cat",
            "/home/agent/workspace/ledgerlab/.env",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    for line in completed.stdout.splitlines():
        if line.startswith("CHAOS_DASHBOARD_TOKEN="):
            return line.split("=", 1)[1]
    raise RuntimeError("Cloud dashboard token was not returned by the sandbox")


def run_scenario(page, label: str, expected_status: str) -> None:
    page.get_by_label("Fault scenario", exact=True).select_option(label=label)
    run_rows = page.locator(".run-list .run-row")
    previous_count = run_rows.count()
    run_button = page.get_by_role("button", name=re.compile(r"^Run experiment"))
    run_button.scroll_into_view_if_needed()
    page.wait_for_timeout(2_000)
    run_button.click()
    expect(run_rows).to_have_count(previous_count + 1, timeout=30_000)
    newest = run_rows.first
    expect(newest).to_contain_text(expected_status, timeout=120_000)
    newest.click()


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists():
        OUTPUT.unlink()

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False)
        context = browser.new_context(
            viewport={"width": 1280, "height": 720},
            record_video_dir=str(OUTPUT.parent),
            record_video_size={"width": 1280, "height": 720},
        )
        page = context.new_page()
        page.goto(URL, wait_until="networkidle", timeout=60_000)

        token_field = page.get_by_label("Dashboard access token", exact=True)
        if token_field.is_visible():
            token_field.fill(cloud_token())
            page.get_by_role("button", name="Open workspace").click()

        page.get_by_role("heading", name="Reconciliation lab.").wait_for(timeout=30_000)
        expect(page.get_by_text(re.compile(r"docker.cloud", re.I), exact=True)).to_be_visible(timeout=30_000)
        page.wait_for_timeout(5_000)

        # Establish the immutable workload and genuine business discrepancy.
        workload = page.get_by_role("heading", name="A ledger with one exception")
        workload.scroll_into_view_if_needed()
        page.wait_for_timeout(8_000)

        page.get_by_label("Execution engine", exact=True).select_option(label="Scripted · local validation only")

        # Live proof: reject the plausible $600 summary and recover from raw rows.
        run_scenario(page, "Plausible wrong total", "Recovered")
        report = page.get_by_role("heading", name="Verified reconciliation")
        report.scroll_into_view_if_needed()
        page.wait_for_timeout(15_000)
        trace = page.get_by_role("heading", name=re.compile(r"What actually happened"))
        trace.scroll_into_view_if_needed()
        page.wait_for_timeout(10_000)

        # Live proof: retry a transient timeout and still verify the $50 finding.
        page.get_by_role("heading", name="Run an experiment").scroll_into_view_if_needed()
        run_scenario(page, "Transient timeout", "Recovered")
        report.scroll_into_view_if_needed()
        page.wait_for_timeout(15_000)

        # Safety proof: a persistent outage halts after the bounded retry.
        page.get_by_role("heading", name="Run an experiment").scroll_into_view_if_needed()
        run_scenario(page, "Persistent outage", "Safe halt")
        stopped = page.get_by_text("Execution stopped safely", exact=True)
        stopped.scroll_into_view_if_needed()
        page.wait_for_timeout(18_000)

        video = page.video
        page.close()
        context.close()
        video.save_as(str(OUTPUT))
        browser.close()

    print(f"Recorded Docker Cloud silent demo: {OUTPUT}")


if __name__ == "__main__":
    main()
