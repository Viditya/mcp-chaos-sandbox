"""SQLite run ledger shared safely by the API, worker, and MCP tool process."""

import hashlib
import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .models import TERMINAL_STATUSES, RunRequest, RunView, utc_now


class Store:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY,
                    idempotency_key TEXT UNIQUE NOT NULL,
                    scenario TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    started_at TEXT,
                    fault_count INTEGER NOT NULL DEFAULT 0,
                    tool_calls INTEGER NOT NULL DEFAULT 0,
                    model_usage TEXT NOT NULL DEFAULT '{}',
                    report TEXT,
                    error TEXT,
                    snapshot_id TEXT NOT NULL DEFAULT 'synthetic-day-001'
                );
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL REFERENCES runs(id),
                    kind TEXT NOT NULL,
                    message TEXT NOT NULL,
                    data TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS events_run_id ON events(run_id,id);
                CREATE TABLE IF NOT EXISTS operations (
                    run_id TEXT NOT NULL REFERENCES runs(id),
                    operation_key TEXT NOT NULL,
                    name TEXT NOT NULL,
                    attempts INTEGER NOT NULL,
                    PRIMARY KEY(run_id,operation_key)
                );
            """)

    @contextmanager
    def _connection(self):
        conn = sqlite3.connect(self.db_path, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=15000")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    @staticmethod
    def _view(row: sqlite3.Row) -> RunView:
        data = dict(row)
        for key in ("model_usage", "report"):
            if data[key] is not None:
                data[key] = json.loads(data[key])
        return RunView.model_validate(data)

    @staticmethod
    def _get(conn: sqlite3.Connection, run_id: str) -> sqlite3.Row:
        row = conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
        if row is None:
            raise KeyError(run_id)
        return row

    @staticmethod
    def _event(
        conn: sqlite3.Connection,
        run_id: str,
        kind: str,
        message: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        created_at = utc_now()
        cursor = conn.execute(
            "INSERT INTO events(run_id,kind,message,data,created_at) VALUES (?,?,?,?,?)",
            (run_id, kind, message, json.dumps(data or {}, allow_nan=False), created_at),
        )
        return {
            "id": cursor.lastrowid,
            "run_id": run_id,
            "kind": kind,
            "message": message,
            "data": data or {},
            "created_at": created_at,
        }

    def create_run(self, request: RunRequest) -> tuple[RunView, bool]:
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            old = conn.execute(
                "SELECT * FROM runs WHERE idempotency_key=?", (request.idempotency_key,)
            ).fetchone()
            if old is not None:
                if old["scenario"] != request.scenario or old["mode"] != request.mode:
                    raise ValueError(
                        "Idempotency key already belongs to a different run configuration"
                    )
                return self._view(old), False
            run_id = str(uuid.uuid4())
            now = utc_now()
            conn.execute(
                "INSERT INTO runs(id,idempotency_key,scenario,mode,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
                (
                    run_id,
                    request.idempotency_key,
                    request.scenario,
                    request.mode,
                    "queued",
                    now,
                    now,
                ),
            )
            self._event(
                conn,
                run_id,
                "run_queued",
                "Run queued",
                {"scenario": request.scenario, "mode": request.mode},
            )
            return self._view(self._get(conn, run_id)), True

    def get_run(self, run_id: str) -> RunView:
        with self._connection() as conn:
            return self._view(self._get(conn, run_id))

    def list_runs(self) -> list[RunView]:
        with self._connection() as conn:
            return [
                self._view(row)
                for row in conn.execute("SELECT * FROM runs ORDER BY created_at DESC,id DESC")
            ]

    def update_run(self, run_id: str, **fields: Any) -> RunView:
        allowed = {
            "status",
            "started_at",
            "fault_count",
            "tool_calls",
            "model_usage",
            "report",
            "error",
        }
        if not set(fields).issubset(allowed):
            raise ValueError("Unsupported run update fields")
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            old = self._view(self._get(conn, run_id))
            if old.status in TERMINAL_STATUSES and fields.get("status", old.status) != old.status:
                raise ValueError("Terminal runs cannot transition to another state")
            merged = old.model_dump() | fields | {"updated_at": utc_now()}
            validated = RunView.model_validate(merged)
            update = {key: getattr(validated, key) for key in fields}
            update["updated_at"] = validated.updated_at
            for key in ("model_usage", "report"):
                if key in update and update[key] is not None:
                    update[key] = json.dumps(update[key], allow_nan=False)
            conn.execute(
                f"UPDATE runs SET {','.join(key + '=?' for key in update)} WHERE id=?",
                (*update.values(), run_id),
            )
            return self._view(self._get(conn, run_id))

    def add_event(
        self, run_id: str, kind: str, message: str, data: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        with self._connection() as conn:
            self._get(conn, run_id)
            return self._event(conn, run_id, kind, message, data)

    def events(self, run_id: str, after: int = 0) -> list[dict[str, Any]]:
        with self._connection() as conn:
            self._get(conn, run_id)
            rows = conn.execute(
                "SELECT * FROM events WHERE run_id=? AND id>? ORDER BY id", (run_id, after)
            )
            return [dict(row) | {"data": json.loads(row["data"])} for row in rows]

    def claim_run(self, run_id: str) -> bool:
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._get(conn, run_id)
            now = utc_now()
            cursor = conn.execute(
                "UPDATE runs SET status='running',started_at=?,updated_at=? WHERE id=? AND status='queued'",
                (now, now, run_id),
            )
            if cursor.rowcount:
                self._event(conn, run_id, "run_started", "Worker claimed run")
            return cursor.rowcount == 1

    def recover_interrupted(self) -> int:
        """Explicitly halt interrupted work; never invent a successful resume."""
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            rows = conn.execute("SELECT id FROM runs WHERE status='running'").fetchall()
            for row in rows:
                reason = (
                    "Worker restarted before completion; previous counters and evidence preserved"
                )
                conn.execute(
                    "UPDATE runs SET status='halted',error=?,updated_at=? WHERE id=?",
                    (reason, utc_now(), row["id"]),
                )
                self._event(conn, row["id"], "run_halted", reason)
            return len(rows)

    def reserve_tool_call(
        self,
        run_id: str,
        name: str,
        arguments: dict[str, Any],
        *,
        max_calls: int = 12,
        max_attempts: int = 2,
        timeout_seconds: float = 180,
    ) -> dict[str, Any]:
        """Atomically reserve a bounded attempt across independent MCP processes."""
        encoded = json.dumps(arguments, sort_keys=True, separators=(",", ":"), allow_nan=False)
        operation_key = hashlib.sha256((name + ":" + encoded).encode()).hexdigest()
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            run = self._view(self._get(conn, run_id))
            if run.status != "running":
                return {
                    "allowed": False,
                    "reason": f"Run is {run.status}; no further tool execution is permitted",
                }
            prior = conn.execute(
                "SELECT attempts FROM operations WHERE run_id=? AND operation_key=?",
                (run_id, operation_key),
            ).fetchone()
            attempt = 1 if prior is None else int(prior["attempts"]) + 1
            elapsed = (
                datetime.now(UTC) - datetime.fromisoformat(run.started_at or run.created_at)
            ).total_seconds()
            reason = None
            if elapsed >= timeout_seconds:
                reason = "Run wall-time budget exhausted"
            elif run.tool_calls >= max_calls:
                reason = "Run tool-call budget exhausted"
            elif attempt > max_attempts:
                reason = f"Attempt budget exhausted for {name}"
            if reason:
                conn.execute(
                    "UPDATE runs SET status='halted',error=?,updated_at=? WHERE id=?",
                    (reason, utc_now(), run_id),
                )
                self._event(conn, run_id, "run_halted", reason, {"tool": name, "attempt": attempt})
                return {"allowed": False, "reason": reason}
            conn.execute(
                "INSERT INTO operations(run_id,operation_key,name,attempts) VALUES (?,?,?,?) ON CONFLICT(run_id,operation_key) DO UPDATE SET attempts=excluded.attempts",
                (run_id, operation_key, name, attempt),
            )
            conn.execute(
                "UPDATE runs SET tool_calls=tool_calls+1,updated_at=? WHERE id=?",
                (utc_now(), run_id),
            )
            self._event(
                conn,
                run_id,
                "tool_started",
                f"Calling {name} (attempt {attempt})",
                {
                    "tool": name,
                    "arguments": arguments,
                    "attempt": attempt,
                    "call_index": run.tool_calls + 1,
                },
            )
            return {
                "allowed": True,
                "attempt": attempt,
                "call_index": run.tool_calls + 1,
                "scenario": run.scenario,
                "operation_key": operation_key,
            }

    def record_tool_result(
        self,
        run_id: str,
        name: str,
        attempt: int,
        result: dict[str, Any],
        *,
        fault: bool = False,
        halt_reason: str | None = None,
    ) -> None:
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            self._get(conn, run_id)
            if fault:
                conn.execute(
                    "UPDATE runs SET fault_count=fault_count+1,updated_at=? WHERE id=?",
                    (utc_now(), run_id),
                )
                self._event(
                    conn,
                    run_id,
                    "fault_injected",
                    f"Injected fault into {name}",
                    {"tool": name, "attempt": attempt},
                )
            self._event(
                conn,
                run_id,
                "tool_result",
                f"{name} {'completed' if result.get('ok') else 'failed'}",
                {"tool": name, "attempt": attempt, "ok": bool(result.get("ok")), "result": result},
            )
            if halt_reason:
                conn.execute(
                    "UPDATE runs SET status='halted',error=?,updated_at=? WHERE id=? AND status='running'",
                    (halt_reason, utc_now(), run_id),
                )
                self._event(conn, run_id, "run_halted", halt_reason)
