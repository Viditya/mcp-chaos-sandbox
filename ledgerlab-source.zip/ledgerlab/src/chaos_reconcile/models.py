"""Validated API and reconciliation contracts."""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

Scenario = Literal[
    "clean", "timeout_once", "truncated_once", "wrong_total_once", "persistent_timeout"
]
Mode = Literal["codex", "scripted"]
RunStatus = Literal["queued", "running", "completed", "recovered", "halted", "failed"]
TERMINAL_STATUSES = frozenset({"completed", "recovered", "halted", "failed"})


class RunRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scenario: Scenario = "clean"
    mode: Mode = "codex"
    idempotency_key: str = Field(min_length=8, max_length=128)

    @field_validator("idempotency_key")
    @classmethod
    def nonblank_key(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("idempotency_key must not be blank")
        return value


class RunView(BaseModel):
    id: str
    scenario: Scenario
    mode: Mode
    status: RunStatus
    created_at: str
    updated_at: str
    started_at: str | None = None
    fault_count: int = 0
    tool_calls: int = 0
    model_usage: dict[str, Any] = Field(default_factory=dict)
    report: dict[str, Any] | None = None
    error: str | None = None
    idempotency_key: str
    snapshot_id: str = "synthetic-day-001"


class Finding(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    order_id: str
    expected_net_cents: int
    received_net_cents: int
    difference_cents: int
    status: Literal["matched", "underpaid", "overpaid"]
    evidence_ids: list[str]


class ReconciliationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    currency: Literal["USD"]
    expected_net_cents: int
    received_net_cents: int
    difference_cents: int
    findings: list[Finding]


def utc_now() -> str:
    from datetime import UTC

    return datetime.now(UTC).isoformat()


Report = ReconciliationReport


def report_json_schema() -> dict[str, Any]:
    return ReconciliationReport.model_json_schema()
