"""Authenticated same-origin API serving the React dashboard and a durable worker."""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import os
import shutil
from contextlib import asynccontextmanager, suppress
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from chaos_reconcile.models import RunRequest, RunView
from chaos_reconcile.store import Store
from chaos_reconcile.tools import MAX_ATTEMPTS, MAX_TOOL_CALLS, TIMEOUT_SECONDS
from chaos_reconcile.worker import Worker

ROOT = Path(__file__).resolve().parents[2]
SCENARIOS: list[dict[str, str]] = [
    {"id": "clean", "label": "Clean baseline", "description": "No injected failure; discover the real underpayment.", "expected_outcome": "completed"},
    {"id": "timeout_once", "label": "Transient timeout", "description": "First payment read times out; one retry can recover.", "expected_outcome": "recovered"},
    {"id": "truncated_once", "label": "Truncated response", "description": "First payment response is incomplete JSON; discard and retry.", "expected_outcome": "recovered"},
    {"id": "wrong_total_once", "label": "Plausible wrong total", "description": "Payment summary is inflated; independent raw ledger rows remain trustworthy.", "expected_outcome": "recovered"},
    {"id": "persistent_timeout", "label": "Persistent outage", "description": "Both payment reads fail; halt without an unverified report.", "expected_outcome": "halted"},
]


class SessionRequest(BaseModel):
    token: str = Field(min_length=1, max_length=512)


class SuiteRequest(BaseModel):
    mode: Literal["codex", "scripted"] = "codex"
    idempotency_key: str = Field(min_length=8, max_length=100)


def create_app(db_path: str | Path | None = None, token: str | None = None) -> FastAPI:
    runtime = Path(os.environ.get("LEDGERLAB_RUNTIME", ROOT / "runtime")).resolve()
    store = Store(db_path or runtime / "ledgerlab.sqlite3")
    worker = Worker(store, runtime / "agents")
    access_token = token if token is not None else os.environ.get("CHAOS_DASHBOARD_TOKEN", "")
    session_value = hmac.new(access_token.encode(), b"ledgerlab-session-v1", hashlib.sha256).hexdigest()
    max_codex_runs = int(os.environ.get("LEDGERLAB_MAX_CODEX_RUNS", "12"))
    secure_cookie = os.environ.get("CHAOS_COOKIE_SECURE", "0") == "1"

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        store.recover_interrupted()
        for run in reversed(store.list_runs()):
            if run.status == "queued":
                worker.enqueue(run.id)
        task = asyncio.create_task(worker.serve())
        yield
        worker.halt_active()
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task

    app = FastAPI(title="LedgerLab", lifespan=lifespan)
    app.state.store = store
    app.state.worker = worker

    async def require_auth(request: Request) -> None:
        if not access_token:
            raise HTTPException(503, "Dashboard access token is not configured; run ledgerlab init.")
        bearer = request.headers.get("authorization", "")
        cookie = request.cookies.get("ledgerlab_session", "")
        if not (hmac.compare_digest(cookie.encode(), session_value.encode()) or hmac.compare_digest(bearer.encode(), f"Bearer {access_token}".encode())):
            raise HTTPException(401, "Sign in with the dashboard access token.")
        origin = request.headers.get("origin")
        if request.method not in ("GET", "HEAD") and origin and urlsplit(origin).netloc != request.headers.get("host"):
            raise HTTPException(403, "Cross-origin writes are not permitted.")

    @app.get("/api/health")
    async def health():
        return {"status": "healthy", "codex_available": bool(shutil.which("codex")), "auth_required": True,
                "environment": os.environ.get("LEDGERLAB_ENVIRONMENT", "local")}

    @app.post("/api/session")
    async def session(body: SessionRequest, response: Response):
        if not access_token or not hmac.compare_digest(body.token.encode(), access_token.encode()):
            raise HTTPException(401, "Invalid dashboard access token.")
        response.set_cookie("ledgerlab_session", session_value, httponly=True, secure=secure_cookie, samesite="strict", max_age=3600)
        return {"authenticated": True}

    @app.delete("/api/session")
    async def logout(response: Response):
        response.delete_cookie("ledgerlab_session")
        return {"authenticated": False}

    @app.get("/api/settings", dependencies=[Depends(require_auth)])
    async def settings():
        return {"codex_available": bool(shutil.which("codex")),
                "environment": os.environ.get("LEDGERLAB_ENVIRONMENT", "local"),
                "limits": {"max_tool_calls": MAX_TOOL_CALLS, "max_attempts": MAX_ATTEMPTS, "timeout_seconds": TIMEOUT_SECONDS, "max_codex_runs": max_codex_runs},
                "budget": {"authorized_usd": 10, "cloud_rate_usd_per_hour": None,
                           "note": "OAuth consumes your Codex plan allowance. Docker meters compute separately; actual charges are in Docker billing. Deployment TTL bounds runtime."},
                "fault_boundary": "Tool responses only. Authoritative immutable source rows remain trusted. Model-provider responses and arbitrary infrastructure failures are not covered."}

    @app.get("/api/scenarios", dependencies=[Depends(require_auth)])
    async def scenarios():
        return SCENARIOS

    def queue_run(body: RunRequest) -> RunView:
        if body.mode == "codex" and not shutil.which("codex"):
            raise HTTPException(409, "Codex is unavailable in this environment. Scripted mode tests plumbing only.")
        existing = next((r for r in store.list_runs() if r.idempotency_key == body.idempotency_key), None)
        if body.mode == "codex" and existing is None and sum(r.mode == "codex" for r in store.list_runs()) >= max_codex_runs:
            raise HTTPException(429, "This deployment has reached its live Codex run allowance.")
        try:
            run, created = store.create_run(body)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        if created:
            worker.enqueue(run.id)
        return run

    @app.post("/api/runs", status_code=202, dependencies=[Depends(require_auth)])
    async def start_run(body: RunRequest):
        return queue_run(body)

    @app.post("/api/suite", status_code=202, dependencies=[Depends(require_auth)])
    async def start_suite(body: SuiteRequest):
        # Validate capacity before scheduling any part of a suite.
        current = store.list_runs()
        for scenario in SCENARIOS:
            key = f"{body.idempotency_key}:{scenario['id']}"
            existing = next((r for r in current if r.idempotency_key == key), None)
            if existing and (existing.mode != body.mode or existing.scenario != scenario["id"]):
                raise HTTPException(409, "Suite idempotency key conflicts with an existing run configuration.")
        missing = sum(not any(r.idempotency_key == f"{body.idempotency_key}:{s['id']}" for r in current) for s in SCENARIOS)
        if body.mode == "codex" and sum(r.mode == "codex" for r in current) + missing > max_codex_runs:
            raise HTTPException(429, "Not enough live-run allowance remains for the complete suite.")
        return {"runs": [queue_run(RunRequest.model_validate({"mode": body.mode, "scenario": s["id"], "idempotency_key": f"{body.idempotency_key}:{s['id']}"})) for s in SCENARIOS]}

    @app.get("/api/runs", dependencies=[Depends(require_auth)])
    async def runs():
        return store.list_runs()

    def get_run(run_id: str):
        try:
            return store.get_run(run_id)
        except KeyError as exc:
            raise HTTPException(404, "Run not found.") from exc

    @app.get("/api/runs/{run_id}", dependencies=[Depends(require_auth)])
    async def run_detail(run_id: str):
        return get_run(run_id)

    @app.get("/api/runs/{run_id}/events", dependencies=[Depends(require_auth)])
    async def events(run_id: str, after: int = 0):
        get_run(run_id)
        return store.events(run_id, after)

    @app.get("/api/runs/{run_id}/export", dependencies=[Depends(require_auth)])
    async def export(run_id: str):
        run = get_run(run_id)
        return JSONResponse({"run": run.model_dump(), "events": store.events(run_id)}, headers={"Content-Disposition": f'attachment; filename="ledgerlab-{run.id}.json"'})

    dist = ROOT / "frontend" / "dist"
    if dist.exists():
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")
        @app.get("/{path:path}")
        async def spa(path: str):
            if path.startswith("api/"):
                raise HTTPException(404, "Unknown API route.")
            return FileResponse(dist / "index.html")
    return app
