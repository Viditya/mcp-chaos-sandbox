"""Local and cloud entry points; credentials never appear in command output."""
from __future__ import annotations

import argparse
import json
import os
import secrets
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]


def load_environment() -> None:
    env_file = ROOT / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key, value)


def main() -> None:
    parser = argparse.ArgumentParser(prog="ledgerlab")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init")
    serve = commands.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8080)
    suite = commands.add_parser("suite")
    suite.add_argument("--mode", choices=["scripted", "codex"], default="scripted")
    suite.add_argument("--output", default="evidence/suite.json")
    args = parser.parse_args()
    if args.command == "init":
        path = ROOT / ".env"
        if not path.exists():
            path.write_text(f"CHAOS_DASHBOARD_TOKEN={secrets.token_urlsafe(32)}\n")
            path.chmod(0o600)
        print(f"Dashboard credential configured in {path}; value was not printed.")
        return
    load_environment()
    if args.command == "serve":
        import uvicorn
        uvicorn.run("chaos_reconcile.api:create_app", factory=True, host=args.host, port=args.port)
    else:
        from chaos_reconcile.api import SCENARIOS
        from chaos_reconcile.models import RunRequest
        from chaos_reconcile.store import Store
        from chaos_reconcile.worker import execute_run
        store = Store(ROOT / "runtime" / "ledgerlab.sqlite3")
        batch = secrets.token_hex(8)
        results: list[dict[str, Any]] = []
        for scenario in SCENARIOS:
            run, _ = store.create_run(RunRequest.model_validate({"mode": args.mode, "scenario": scenario["id"], "idempotency_key": f"cli-{batch}-{scenario['id']}"}))
            execute_run(store, run.id, ROOT / "runtime" / "agents")
            results.append({"run": store.get_run(run.id).model_dump(), "events": store.events(run.id)})
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps({"mode": args.mode, "runs": results}, indent=2))
        print(json.dumps({"output": str(out), "results": [{"scenario": r["run"]["scenario"], "status": r["run"]["status"]} for r in results]}))
        if any(r["run"]["status"] != s["expected_outcome"] for r, s in zip(results, SCENARIOS, strict=True)):
            raise SystemExit(1)
