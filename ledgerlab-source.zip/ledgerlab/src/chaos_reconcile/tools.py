"""Bounded read-only agent tools and deterministic tool-boundary chaos."""

from typing import Any

from .domain import SNAPSHOT_ID, get_snapshot, verify_report
from .store import Store

TOOL_NAMES = frozenset(
    {"read_orders", "read_payments", "read_refunds", "read_payment_rows", "inspect_order"}
)
REQUIRED_TOOLS = frozenset({"read_orders", "read_payments", "read_refunds", "read_payment_rows"})
MAX_TOOL_CALLS = 12
MAX_ATTEMPTS = 2
TIMEOUT_SECONDS = 180


class ToolService:
    def __init__(
        self,
        store: Store,
        run_id: str,
        *,
        max_calls: int = MAX_TOOL_CALLS,
        max_attempts: int = MAX_ATTEMPTS,
        timeout_seconds: float = TIMEOUT_SECONDS,
    ):
        self.store = store
        self.run_id = run_id
        self.max_calls = max_calls
        self.max_attempts = max_attempts
        self.timeout_seconds = timeout_seconds

    @staticmethod
    def _error(code: str, message: str, retryable: bool = False) -> dict[str, Any]:
        return {"ok": False, "error": {"code": code, "message": message, "retryable": retryable}}

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        # Normalize equivalent snapshot parameters so changing syntactic spelling
        # cannot reset an operation's persisted retry allowance.
        normalized = dict(arguments)
        if normalized.get("snapshot_id") == SNAPSHOT_ID:
            normalized.pop("snapshot_id")
        reservation = self.store.reserve_tool_call(
            self.run_id,
            name,
            normalized,
            max_calls=self.max_calls,
            max_attempts=self.max_attempts,
            timeout_seconds=self.timeout_seconds,
        )
        if not reservation["allowed"]:
            return self._error("run_halted", reservation["reason"])
        attempt = reservation["attempt"]
        scenario = reservation["scenario"]
        fault = False
        halt_reason = None
        result: dict[str, Any]
        if name not in TOOL_NAMES:
            result = self._error(
                "tool_forbidden", "Only the five bounded read-only ledger tools are permitted"
            )
        elif arguments.get("snapshot_id", SNAPSHOT_ID) != SNAPSHOT_ID:
            result = self._error(
                "snapshot_mismatch", "Requested snapshot is not the pinned run snapshot"
            )
        elif set(normalized) - ({"order_id"} if name == "inspect_order" else set()):
            result = self._error("invalid_arguments", "Unexpected tool arguments")
        elif name == "inspect_order" and normalized.get("order_id") not in {"A", "B", "C"}:
            result = self._error("invalid_arguments", "order_id must be A, B, or C")
        elif name == "read_payments" and (
            scenario == "persistent_timeout" or scenario == "timeout_once" and attempt == 1
        ):
            fault = True
            exhausted = attempt >= self.max_attempts
            result = self._error(
                "upstream_timeout",
                "Payment service timed out; retry the same operation once",
                not exhausted,
            )
            if exhausted:
                halt_reason = (
                    "Payment service remained unavailable after the bounded attempt allowance"
                )
        elif name == "read_payments" and scenario == "truncated_once" and attempt == 1:
            fault = True
            result = self._error(
                "truncated_response",
                "Payment service returned incomplete JSON; discard it and retry once",
                True,
            )
            result["raw_response"] = '{"snapshot_id":"synthetic-day-001","payments":['
        else:
            source = get_snapshot()
            result = {"ok": True, "snapshot_id": SNAPSHOT_ID, "currency": "USD"}
            if name == "read_orders":
                result.update(orders=source["orders"], policy=source["policy"])
            elif name == "read_refunds":
                result["refunds"] = source["refunds"]
            elif name in {"read_payments", "read_payment_rows"}:
                result["payments"] = source["payments"]
                if name == "read_payments":
                    result["total_received_cents"] = sum(
                        row["amount_cents"]
                        for row in source["payments"]
                        if row["status"] == "captured"
                    )
                    if scenario == "wrong_total_once" and attempt == 1:
                        fault = True
                        result["total_received_cents"] += 5000
            elif name == "inspect_order":
                order_id = normalized["order_id"]
                result.update(
                    {
                        "order": next(
                            row for row in source["orders"] if row["order_id"] == order_id
                        ),
                        "payments": [
                            row for row in source["payments"] if row["order_id"] == order_id
                        ],
                        "refunds": [
                            row for row in source["refunds"] if row["order_id"] == order_id
                        ],
                    }
                )
        self.store.record_tool_result(
            self.run_id, name, attempt, result, fault=fault, halt_reason=halt_reason
        )
        return result

    def verify_report(
        self, candidate: dict[str, Any], snapshot: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        run = self.store.get_run(self.run_id)
        if run.status != "running":
            raise ValueError(f"Cannot verify a report for a {run.status} run")
        events = self.store.events(self.run_id)
        observed = {
            event["data"].get("tool")
            for event in events
            if event["kind"] == "tool_result" and event["data"].get("ok")
        }
        missing = REQUIRED_TOOLS - observed
        if missing:
            raise ValueError(
                f"Required independent source tools were not completed: {', '.join(sorted(missing))}"
            )
        if run.scenario != "clean" and not run.fault_count:
            raise ValueError("Configured chaos never fired; this is not a valid chaos experiment")
        report = verify_report(candidate, snapshot)
        self.store.add_event(
            self.run_id,
            "report_verified",
            "All financial claims and evidence references match authoritative ledger rows",
            {
                "snapshot_id": SNAPSHOT_ID,
                "expected_net_cents": report["expected_net_cents"],
                "received_net_cents": report["received_net_cents"],
                "difference_cents": report["difference_cents"],
            },
        )
        return report
