"""Actual stdio MCP bridge; only bounded ledger reads are exposed to Codex."""
from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from chaos_reconcile.store import Store
from chaos_reconcile.tools import ToolService


def main() -> None:
    store = Store(os.environ["LEDGERLAB_DB"])
    service = ToolService(store, os.environ["LEDGERLAB_RUN_ID"])
    server = FastMCP(
        "LedgerLab",
        instructions=(
            "Read-only synthetic payment reconciliation. Responses may be unavailable, truncated, "
            "or inconsistent. Retry a failed operation once only. Verify payment summary against "
            "read_payment_rows; never invent missing records. Return a report only with complete "
            "source evidence. All amounts are integer minor units. No external actions are available."
        ),
    )
    annotations = ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=True)

    @server.tool(annotations=annotations)
    def read_orders() -> dict:
        """Read orders for the immutable daily snapshot and its payment policy."""
        return service.call("read_orders", {})

    @server.tool(annotations=annotations)
    def read_payments() -> dict | str:
        """Read payment records and their reported gross captured total. Retry once on error."""
        result = service.call("read_payments", {})
        if "raw_response" in result:
            return result["raw_response"]
        return result

    @server.tool(annotations=annotations)
    def read_refunds() -> dict:
        """Read approved and settled refunds for the daily snapshot."""
        return service.call("read_refunds", {})

    @server.tool(annotations=annotations)
    def read_payment_rows() -> dict:
        """Read independent raw payment ledger rows to cross-check reported payment totals."""
        return service.call("read_payment_rows", {})

    @server.tool(annotations=annotations)
    def inspect_order(order_id: str) -> dict:
        """Read evidence for one specific order to investigate a discrepancy."""
        return service.call("inspect_order", {"order_id": order_id})

    server.run(transport="stdio")


if __name__ == "__main__":
    main()
