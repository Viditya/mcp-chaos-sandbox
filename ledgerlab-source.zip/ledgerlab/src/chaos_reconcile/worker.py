"""Single worker: genuine execution, independent validation, truthful terminal states."""
from __future__ import annotations

import asyncio
from pathlib import Path

from chaos_reconcile.codex_runner import run_codex
from chaos_reconcile.domain import reconcile
from chaos_reconcile.models import report_json_schema
from chaos_reconcile.store import Store
from chaos_reconcile.tools import ToolService


def run_scripted(store: Store, run_id: str) -> dict:
    """Deterministic plumbing test, explicitly not a real model resilience result."""
    tools = ToolService(store, run_id)
    store.add_event(run_id, "scripted_started", "Scripted validation only: no model inference is used.")
    outputs = {}
    for name in ("read_orders", "read_payments", "read_refunds", "read_payment_rows"):
        result = tools.call(name, {})
        if not result.get("ok"):
            store.add_event(run_id, "retry_scheduled", f"Retrying {name} once after invalid or unavailable response.")
            result = tools.call(name, {})
        if not result.get("ok"):
            raise RuntimeError("Required source unavailable after bounded retry.")
        outputs[name] = result
    reported = outputs["read_payments"]["total_received_cents"]
    rows = outputs["read_payment_rows"]["payments"]
    actual = sum(row["amount_cents"] for row in rows if row["status"] == "captured")
    if reported != actual:
        store.add_event(run_id, "inconsistency_detected", "Payment summary disagrees with independent raw ledger rows; recomputing.", {"reported_cents": reported, "raw_cents": actual})
    snapshot = {"orders": outputs["read_orders"]["orders"], "payments": rows,
                "refunds": outputs["read_refunds"]["refunds"], "currency": "USD",
                "snapshot_id": outputs["read_orders"]["snapshot_id"], "policy": outputs["read_orders"]["policy"]}
    candidate = reconcile(snapshot)
    for finding in candidate["findings"]:
        if finding["status"] != "matched":
            tools.call("inspect_order", {"order_id": finding["order_id"]})
    return candidate


def execute_run(store: Store, run_id: str, work_root: Path) -> None:
    if not store.claim_run(run_id):
        return
    try:
        run = store.get_run(run_id)
        candidate = (run_codex(store, run_id, work_root, report_json_schema())
                     if run.mode == "codex" else run_scripted(store, run_id))
        report = ToolService(store, run_id).verify_report(candidate)
        status = "recovered" if store.get_run(run_id).fault_count else "completed"
        store.update_run(run_id, status=status, report=report)
        store.add_event(run_id, "run_finished", "Verified report saved.", {"status": status, "mode": run.mode})
    except Exception as exc:
        run = store.get_run(run_id)
        if run.status != "halted":
            # Invalid/unverifiable reports are safe halts; infra failures remain separate.
            status = "halted" if isinstance(exc, (ValueError, TimeoutError)) else "failed"
            store.update_run(run_id, status=status, error=str(exc))
        store.add_event(run_id, "run_finished", str(exc), {"status": store.get_run(run_id).status})


class Worker:
    def __init__(self, store: Store, work_root: Path):
        self.store = store
        self.work_root = work_root
        self.queue: asyncio.Queue[str] = asyncio.Queue()
        self.active: str | None = None

    def enqueue(self, run_id: str) -> None:
        self.queue.put_nowait(run_id)

    async def serve(self) -> None:
        while True:
            run_id = await self.queue.get()
            self.active = run_id
            try:
                await asyncio.to_thread(execute_run, self.store, run_id, self.work_root)
            finally:
                self.active = None
                self.queue.task_done()

    def halt_active(self) -> None:
        if self.active and self.store.get_run(self.active).status == "running":
            self.store.update_run(self.active, status="halted", error="Worker stopped before verification; run can be repeated with a new key.")
