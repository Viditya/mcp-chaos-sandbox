"""Exercise actual subprocess lifecycle with fake local executables, never a model."""

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from chaos_reconcile.codex_runner import run_codex, terminate_group
from chaos_reconcile.domain import expected_report
from chaos_reconcile.models import RunRequest, report_json_schema
from chaos_reconcile.store import Store


def _run(tmp_path):
    store = Store(tmp_path / "runs.sqlite3")
    run, _ = store.create_run(RunRequest(mode="codex", idempotency_key="fake-runner-process"))
    store.claim_run(run.id)
    return store, run.id


def _fake_cli(tmp_path: Path, monkeypatch, body: str) -> Path:
    executable = tmp_path / "fake-codex"
    executable.write_text(f"#!{sys.executable}\n" + body)
    executable.chmod(0o700)
    monkeypatch.setattr("chaos_reconcile.codex_runner.shutil.which", lambda _: str(executable))
    return executable


def test_structured_output_and_real_jsonl_usage_are_read(tmp_path, monkeypatch):
    store, run_id = _run(tmp_path)
    report = expected_report()
    _fake_cli(
        tmp_path,
        monkeypatch,
        f"""
import json, pathlib, sys
args = sys.argv[1:]
assert '--sandbox' in args and args[args.index('--sandbox') + 1] == 'read-only'
assert 'shell_tool' in args and 'browser_use' in args
candidate = pathlib.Path(args[args.index('--output-last-message') + 1])
candidate.write_text({json.dumps(json.dumps(report))})
print(json.dumps({{'type':'turn.completed','usage':{{'input_tokens':42,'output_tokens':12}}}}))
""",
    )
    result = run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert result == report
    assert store.get_run(run_id).model_usage == {"input_tokens": 42, "output_tokens": 12}
    kinds = [event["kind"] for event in store.events(run_id)]
    assert "agent_started" in kinds and "candidate_received" in kinds
    # The runner only received a candidate; it did not claim successful reconciliation.
    assert store.get_run(run_id).status == "running"
    assert store.get_run(run_id).report is None


def test_missing_structured_report_is_an_explicit_failure(tmp_path, monkeypatch):
    store, run_id = _run(tmp_path)
    _fake_cli(tmp_path, monkeypatch, 'print(\'{"type":"turn.completed","usage":{}}\')\n')
    with pytest.raises(RuntimeError, match="without a structured report"):
        run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert not any(event["kind"] == "candidate_received" for event in store.events(run_id))


def test_provider_errors_do_not_expose_private_diagnostics(tmp_path, monkeypatch):
    store, run_id = _run(tmp_path)
    _fake_cli(
        tmp_path,
        monkeypatch,
        "import sys\nprint('PRIVATE_AUTH_DIAGNOSTIC',file=sys.stderr)\nsys.exit(2)\n",
    )
    with pytest.raises(RuntimeError, match="exited with code 2") as caught:
        run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert "PRIVATE_AUTH_DIAGNOSTIC" not in str(caught.value)
    assert "PRIVATE_AUTH_DIAGNOSTIC" not in json.dumps(store.events(run_id))
    assert (
        "PRIVATE_AUTH_DIAGNOSTIC" in (tmp_path / "agents" / run_id / "codex-stderr.log").read_text()
    )


def test_unexpected_shell_capability_is_rejected_even_with_correct_report(tmp_path, monkeypatch):
    store, run_id = _run(tmp_path)
    _fake_cli(
        tmp_path,
        monkeypatch,
        f"""
import json, pathlib, sys
args=sys.argv[1:]
pathlib.Path(args[args.index('--output-last-message')+1]).write_text({json.dumps(json.dumps(expected_report()))})
print(json.dumps({{'type':'item.completed','item':{{'type':'command_execution','command':'cat hidden-ledger'}}}}))
""",
    )
    with pytest.raises(RuntimeError, match="Unexpected agent capabilities"):
        run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert not any(event["kind"] == "candidate_received" for event in store.events(run_id))


def test_deadline_terminates_process_group(tmp_path, monkeypatch):
    store, run_id = _run(tmp_path)
    _fake_cli(tmp_path, monkeypatch, "import time\ntime.sleep(30)\n")
    clock = iter([0.0, 181.0])
    monkeypatch.setattr(
        "chaos_reconcile.codex_runner.time",
        SimpleNamespace(monotonic=lambda: next(clock), sleep=time.sleep),
    )
    signals = []
    original = os.killpg

    def observed_killpg(group, sig):
        signals.append((group, sig))
        original(group, sig)

    monkeypatch.setattr("chaos_reconcile.codex_runner.os.killpg", observed_killpg)
    with pytest.raises(TimeoutError, match="180-second"):
        run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert signals and signals[0][1] == signal.SIGTERM
    assert store.get_run(run_id).model_usage["status"] == "incomplete"
    assert not any(event["kind"] == "candidate_received" for event in store.events(run_id))


def test_external_halt_terminates_agent_instead_of_accepting_a_candidate(tmp_path, monkeypatch):
    store, run_id = _run(tmp_path)
    _fake_cli(tmp_path, monkeypatch, "import time\ntime.sleep(30)\n")
    store.update_run(run_id, status="halted", error="Policy stopped the run")
    signals = []
    original = os.killpg

    def observed_killpg(group, sig):
        signals.append((group, sig))
        original(group, sig)

    monkeypatch.setattr("chaos_reconcile.codex_runner.os.killpg", observed_killpg)
    with pytest.raises(RuntimeError, match="Tool policy halted"):
        run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert signals and signals[0][1] == signal.SIGTERM
    assert store.get_run(run_id).status == "halted"
    assert store.get_run(run_id).report is None
    assert store.get_run(run_id).model_usage["status"] == "incomplete"


def test_terminate_group_is_idempotent_for_an_exited_process():
    process = subprocess.Popen([sys.executable, "-c", "pass"], text=True, start_new_session=True)
    process.wait(timeout=5)
    terminate_group(process)
    terminate_group(process)
    assert process.returncode == 0


def test_descendant_ignoring_term_is_killed_after_main_process_has_exited(tmp_path, monkeypatch):
    marker = tmp_path / "descendant.pid"
    child_code = (
        "import os, pathlib, signal, time; "
        "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
        f"pathlib.Path({str(marker)!r}).write_text(str(os.getpid())); "
        "time.sleep(30)"
    )
    parent_code = (
        "import pathlib, subprocess, sys, time\n"
        f"subprocess.Popen([sys.executable, '-c', {child_code!r}], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
        f"marker=pathlib.Path({str(marker)!r})\n"
        "while not marker.exists(): time.sleep(0.01)\n"
    )
    process = subprocess.Popen(
        [sys.executable, "-c", parent_code], text=True, start_new_session=True
    )
    original = os.killpg
    signals = []

    def observed_killpg(group, sig):
        signals.append((group, sig))
        original(group, sig)

    monkeypatch.setattr("chaos_reconcile.codex_runner.os.killpg", observed_killpg)
    try:
        process.wait(timeout=5)
        assert process.returncode == 0
        child_pid = int(marker.read_text())
        # The child kept the exited parent's group and explicitly ignores TERM.
        assert os.getpgid(child_pid) == process.pid
        terminate_group(process)
        assert (process.pid, signal.SIGKILL) in signals
        for _ in range(100):
            result = subprocess.run(
                ["ps", "-o", "stat=", "-p", str(child_pid)],
                text=True,
                capture_output=True,
                check=False,
            )
            if not result.stdout.strip() or result.stdout.strip().startswith("Z"):
                break
            time.sleep(0.01)
        else:
            pytest.fail("MCP-like descendant remained executable after its parent exited")
    finally:
        try:
            original(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def test_interrupted_run_collects_usage_already_emitted_before_halt(tmp_path, monkeypatch):
    store, run_id = _run(tmp_path)
    _fake_cli(
        tmp_path,
        monkeypatch,
        "import json,time\nprint(json.dumps({'type':'turn.completed','usage':{'input_tokens':37,'output_tokens':11}}),flush=True)\ntime.sleep(30)\n",
    )
    event_path = tmp_path / "agents" / run_id / "codex-events.jsonl"

    def halt_after_output(_seconds):
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            if event_path.exists() and "turn.completed" in event_path.read_text():
                store.update_run(run_id, status="halted", error="Shutdown during cleanup")
                return
            time.sleep(0.01)
        pytest.fail("Fake process failed to emit usage")

    monkeypatch.setattr(
        "chaos_reconcile.codex_runner.time",
        SimpleNamespace(monotonic=time.monotonic, sleep=halt_after_output),
    )
    with pytest.raises(RuntimeError, match="Tool policy halted"):
        run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert store.get_run(run_id).model_usage == {"input_tokens": 37, "output_tokens": 11}
    assert store.get_run(run_id).status == "halted"


def test_docker_provider_configuration_is_preserved_while_inherited_mcp_is_disabled(
    tmp_path, monkeypatch
):
    import tomllib

    store, run_id = _run(tmp_path)
    codex_config_dir = tmp_path / "isolated-codex-config"
    codex_config_dir.mkdir()
    config_text = """model_provider = "docker_subscription_proxy"
[model_providers.docker_subscription_proxy]
name = "Docker subscription routing"
base_url = "http://subscription-proxy.invalid/v1"
wire_api = "responses"
requires_openai_auth = false
[mcp_servers.other]
command = "never-launch-other-server"
[mcp_servers.other-server]
command = "never-launch-hyphenated-server"
[mcp_servers.other_server]
command = "never-launch-underscored-server"
[mcp_servers.ledgerlab]
enabled = false
command = "do-not-use-inherited-ledgerlab"
"""
    config_path = codex_config_dir / "config.toml"
    config_path.write_text(config_text)
    monkeypatch.setenv("CODEX_HOME", str(codex_config_dir))
    capture = tmp_path / "captured-args.json"
    _fake_cli(
        tmp_path,
        monkeypatch,
        f"""
import json, pathlib, sys
args = sys.argv[1:]
pathlib.Path({str(capture)!r}).write_text(json.dumps(args))
pathlib.Path(args[args.index('--output-last-message') + 1]).write_text({json.dumps(json.dumps(expected_report()))})
print(json.dumps({{'type':'turn.completed','usage':{{'input_tokens':7,'output_tokens':3}}}}))
""",
    )
    assert run_codex(store, run_id, tmp_path / "agents", report_json_schema()) == expected_report()
    args = json.loads(capture.read_text())
    assert "--ignore-user-config" not in args
    assert config_path.read_text() == config_text
    overrides = [args[index + 1] for index, value in enumerate(args) if value == "-c"]
    mcp_overrides = {}
    for override in overrides:
        # Codex's dot-key CLI parser treats quoted segments literally, unlike a
        # TOML file parser. Generated/inherited CLI key segments must be bare.
        keypath = override.split("=", 1)[0]
        assert '"' not in keypath and "'" not in keypath
        parsed = tomllib.loads(override)
        assert "model_provider" not in parsed
        assert "model_providers" not in parsed
        for name, fields in parsed.get("mcp_servers", {}).items():
            mcp_overrides.setdefault(name, {}).update(fields)
    own = [name for name, fields in mcp_overrides.items() if fields.get("required") is True]
    assert len(own) == 1
    own_name = own[0]
    assert len(f"mcp__{own_name}__read_payment_rows") <= 64
    assert mcp_overrides[own_name]["command"] == sys.executable
    assert mcp_overrides[own_name]["args"] == ["-m", "chaos_reconcile.mcp_server"]
    assert mcp_overrides[own_name]["enabled"] is True
    for inherited_name in ("other", "other-server", "other_server", "ledgerlab"):
        if inherited_name != own_name:
            assert mcp_overrides[inherited_name]["enabled"] is False


@pytest.mark.parametrize("invalid_name", ["name.with.dots", 'quoted"server', "space server"])
def test_unsupported_inherited_mcp_name_fails_closed_before_invoking_agent(
    tmp_path, monkeypatch, invalid_name
):
    store, run_id = _run(tmp_path)
    codex_config_dir = tmp_path / "isolated-invalid-config"
    codex_config_dir.mkdir()
    (codex_config_dir / "config.toml").write_text(
        f"[mcp_servers.{json.dumps(invalid_name)}]\ncommand='never-launch-inherited'\n"
    )
    monkeypatch.setenv("CODEX_HOME", str(codex_config_dir))
    invoked = tmp_path / "agent-was-invoked"
    _fake_cli(
        tmp_path,
        monkeypatch,
        f"import pathlib\npathlib.Path({str(invoked)!r}).write_text('invoked')\n",
    )
    with pytest.raises(ValueError, match="Unsupported inherited MCP server name"):
        run_codex(store, run_id, tmp_path / "agents", report_json_schema())
    assert not invoked.exists()
    assert not any(event["kind"] == "agent_started" for event in store.events(run_id))
    assert store.get_run(run_id).report is None
