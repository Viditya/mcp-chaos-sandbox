"""Worker outcomes must reflect verified results, policy halts, and real failures."""

import pytest

from chaos_reconcile.domain import expected_report
from chaos_reconcile.models import RunRequest
from chaos_reconcile.store import Store
from chaos_reconcile.worker import Worker, execute_run


@pytest.mark.parametrize(
    ("scenario", "status", "faults"),
    [
        ("clean", "completed", 0),
        ("timeout_once", "recovered", 1),
        ("truncated_once", "recovered", 1),
        ("wrong_total_once", "recovered", 1),
        ("persistent_timeout", "halted", 2),
    ],
)
def test_scripted_scenarios_have_verified_independent_outcomes(tmp_path, scenario, status, faults):
    store = Store(tmp_path / "ledger.sqlite3")
    run, _ = store.create_run(
        RunRequest(scenario=scenario, mode="scripted", idempotency_key=f"worker-{scenario}")
    )
    execute_run(store, run.id, tmp_path / "agents")
    result = store.get_run(run.id)
    assert result.status == status
    assert result.fault_count == faults
    assert result.mode == "scripted"
    assert result.model_usage == {}
    events = store.events(run.id)
    assert any(event["kind"] == "scripted_started" for event in events)
    if status == "halted":
        assert result.report is None
        assert result.error
        assert not any(event["kind"] == "report_verified" for event in events)
    else:
        assert result.report == expected_report()
        assert any(event["kind"] == "report_verified" for event in events)
    if scenario == "wrong_total_once":
        assert any(event["kind"] == "inconsistency_detected" for event in events)


def test_completed_run_is_not_reexecuted_on_duplicate_queue_delivery(tmp_path):
    store = Store(tmp_path / "ledger.sqlite3")
    run, _ = store.create_run(
        RunRequest(mode="scripted", idempotency_key="duplicate-worker-delivery")
    )
    execute_run(store, run.id, tmp_path / "agents")
    saved = store.get_run(run.id).model_dump()
    events = store.events(run.id)
    execute_run(store, run.id, tmp_path / "agents")
    assert store.get_run(run.id).model_dump() == saved
    assert store.events(run.id) == events


def test_unverified_candidate_is_halted_not_completed(tmp_path, monkeypatch):
    store = Store(tmp_path / "ledger.sqlite3")
    run, _ = store.create_run(RunRequest(mode="codex", idempotency_key="unverified-agent-report"))
    monkeypatch.setattr("chaos_reconcile.worker.run_codex", lambda *_: expected_report())
    execute_run(store, run.id, tmp_path / "agents")
    # Correct numbers without evidence of source reads do not count as success.
    result = store.get_run(run.id)
    assert result.status == "halted" and result.report is None
    assert result.error is not None
    assert "Required independent source" in result.error


def test_agent_infrastructure_failure_is_failed_not_safe_recovery(tmp_path, monkeypatch):
    store = Store(tmp_path / "ledger.sqlite3")
    run, _ = store.create_run(RunRequest(mode="codex", idempotency_key="infrastructure-failure"))

    def failed_provider(*_):
        raise RuntimeError("Provider could not start")

    monkeypatch.setattr("chaos_reconcile.worker.run_codex", failed_provider)
    execute_run(store, run.id, tmp_path / "agents")
    result = store.get_run(run.id)
    assert result.status == "failed" and result.report is None
    assert result.error == "Provider could not start"


def test_shutdown_halt_wins_race_with_agent_return(tmp_path, monkeypatch):
    store = Store(tmp_path / "ledger.sqlite3")
    run, _ = store.create_run(RunRequest(mode="codex", idempotency_key="shutdown-result-race"))
    worker = Worker(store, tmp_path / "agents")
    worker.active = run.id

    def agent_returns_after_shutdown(*_):
        worker.halt_active()
        return expected_report()

    monkeypatch.setattr("chaos_reconcile.worker.run_codex", agent_returns_after_shutdown)
    execute_run(store, run.id, tmp_path / "agents")
    assert store.get_run(run.id).status == "halted"
    assert store.get_run(run.id).report is None


def test_tool_budget_halt_is_preserved_when_worker_catches_exception(tmp_path, monkeypatch):
    from chaos_reconcile.tools import ToolService

    store = Store(tmp_path / "ledger.sqlite3")
    run, _ = store.create_run(RunRequest(mode="codex", idempotency_key="tool-budget-worker"))

    def exhausted_provider(*_):
        service = ToolService(store, run.id, max_calls=1)
        service.call("read_orders", {})
        assert not service.call("read_payments", {})["ok"]
        raise RuntimeError("Agent interrupted after tool-policy halt")

    monkeypatch.setattr("chaos_reconcile.worker.run_codex", exhausted_provider)
    execute_run(store, run.id, tmp_path / "agents")
    result = store.get_run(run.id)
    assert result.status == "halted"
    assert result.tool_calls == 1 and result.report is None
    assert result.error == "Run tool-call budget exhausted"
