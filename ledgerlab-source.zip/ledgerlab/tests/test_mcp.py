"""Real stdio MCP wire checks: launch the exact module used by cloud Codex."""

import asyncio
import json
import sys
from datetime import timedelta
from typing import Any

import pytest
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client
from mcp.types import CallToolResult, TextContent

from chaos_reconcile.domain import expected_report, reconcile
from chaos_reconcile.models import RunRequest
from chaos_reconcile.store import Store
from chaos_reconcile.tools import TOOL_NAMES, ToolService


def _payload(result: CallToolResult) -> dict[str, Any]:
    assert not result.isError
    if result.structuredContent is not None:
        structured = result.structuredContent
        # FastMCP wraps union-return values under result; ordinary dict-return
        # tools expose their object directly.
        if isinstance(structured.get("result"), dict):
            return structured["result"]
        return structured
    texts = [item.text for item in result.content if isinstance(item, TextContent)]
    assert len(texts) == 1
    decoded = json.loads(texts[0])
    assert isinstance(decoded, dict)
    return decoded


def _run(tmp_path, scenario="clean"):
    store = Store(tmp_path / "mcp.sqlite3")
    run, _ = store.create_run(
        RunRequest(mode="scripted", scenario=scenario, idempotency_key=f"wire-{scenario}")
    )
    store.claim_run(run.id)
    return store, run.id


async def _connect(store, run_id, callback, stderr_path):
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "chaos_reconcile.mcp_server"],
        env={"LEDGERLAB_DB": store.db_path, "LEDGERLAB_RUN_ID": run_id},
    )
    with stderr_path.open("w") as errlog:
        async with asyncio.timeout(12):
            async with stdio_client(params, errlog=errlog) as (read_stream, write_stream):
                async with ClientSession(
                    read_stream, write_stream, read_timeout_seconds=timedelta(seconds=5)
                ) as session:
                    initialized = await session.initialize()
                    assert initialized.serverInfo.name == "LedgerLab"
                    await callback(session)


def test_module_starts_actual_mcp_and_reconciles_through_its_tools(tmp_path):
    store, run_id = _run(tmp_path)

    async def exercise(session):
        catalog = await session.list_tools()
        assert {tool.name for tool in catalog.tools} == TOOL_NAMES
        for tool in catalog.tools:
            assert tool.annotations is not None
            assert tool.annotations.readOnlyHint is True
            assert tool.annotations.destructiveHint is False
        outputs = {}
        for name in ("read_orders", "read_payments", "read_refunds", "read_payment_rows"):
            outputs[name] = _payload(await session.call_tool(name, {}))
            assert outputs[name]["ok"] is True
        inspected = _payload(await session.call_tool("inspect_order", {"order_id": "B"}))
        assert inspected["order"]["id"] == "O-B"
        assert inspected["payments"][0]["amount_cents"] == 15000
        snapshot = {
            "snapshot_id": outputs["read_orders"]["snapshot_id"],
            "currency": outputs["read_orders"]["currency"],
            "policy": outputs["read_orders"]["policy"],
            "orders": outputs["read_orders"]["orders"],
            "payments": outputs["read_payment_rows"]["payments"],
            "refunds": outputs["read_refunds"]["refunds"],
        }
        assert ToolService(store, run_id).verify_report(reconcile(snapshot)) == expected_report()

    asyncio.run(_connect(store, run_id, exercise, tmp_path / "mcp.stderr"))
    assert store.get_run(run_id).tool_calls == 5


def test_truncation_is_malformed_tool_text_then_retry_recovers(tmp_path):
    store, run_id = _run(tmp_path, "truncated_once")

    async def exercise(session):
        first = await session.call_tool("read_payments", {})
        texts = [item.text for item in first.content if isinstance(item, TextContent)]
        assert len(texts) == 1
        assert texts[0].endswith("[")
        with pytest.raises(json.JSONDecodeError):
            json.loads(texts[0])
        second = _payload(await session.call_tool("read_payments", {}))
        assert second["ok"] and second["total_received_cents"] == 55000

    asyncio.run(_connect(store, run_id, exercise, tmp_path / "mcp.stderr"))
    assert store.get_run(run_id).fault_count == 1
    assert store.get_run(run_id).tool_calls == 2


def test_persistent_timeout_halts_across_real_mcp_calls(tmp_path):
    store, run_id = _run(tmp_path, "persistent_timeout")

    async def exercise(session):
        first = _payload(await session.call_tool("read_payments", {}))
        second = _payload(await session.call_tool("read_payments", {}))
        assert first["error"]["code"] == second["error"]["code"] == "upstream_timeout"
        assert first["error"]["retryable"] is True
        assert second["error"]["retryable"] is False
        after_halt = _payload(await session.call_tool("read_orders", {}))
        assert after_halt["error"]["code"] == "run_halted"

    asyncio.run(_connect(store, run_id, exercise, tmp_path / "mcp.stderr"))
    assert store.get_run(run_id).status == "halted"
    assert store.get_run(run_id).tool_calls == 2


def test_mcp_argument_schema_rejects_missing_order_id(tmp_path):
    store, run_id = _run(tmp_path)

    async def exercise(session):
        denied = await session.call_tool("inspect_order", {})
        assert denied.isError
        assert store.get_run(run_id).tool_calls == 0
        unknown = await session.call_tool("execute_refund", {"order_id": "B"})
        assert unknown.isError
        assert store.get_run(run_id).tool_calls == 0

    asyncio.run(_connect(store, run_id, exercise, tmp_path / "mcp.stderr"))
