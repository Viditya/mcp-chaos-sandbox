"""Behavioral checks for trusted reconciliation, durable budgets, and real faults."""

import concurrent.futures
from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError

from chaos_reconcile.domain import expected_report, get_snapshot, reconcile, verify_report
from chaos_reconcile.models import RunRequest
from chaos_reconcile.store import Store
from chaos_reconcile.tools import ToolService


def setup_run(tmp_path, scenario="clean", **limits):
    store = Store(tmp_path / "runs.db")
    run, _ = store.create_run(
        RunRequest(scenario=scenario, idempotency_key="core-test-run", mode="scripted")
    )
    assert store.claim_run(run.id)
    return store, run.id, ToolService(store, run.id, **limits)


def test_golden_oracle_and_mutation_isolation():
    assert reconcile(get_snapshot()) == expected_report()
    copy = get_snapshot()
    copy["payments"][0]["amount_cents"] = 0
    assert reconcile(get_snapshot()) == expected_report()
    assert reconcile(copy) != expected_report()


def test_verifier_rejects_plausible_wrong_amount_and_missing_evidence():
    for field in ("received_net_cents", "expected_net_cents", "difference_cents"):
        candidate = expected_report()
        candidate[field] += 1
        with pytest.raises(ValueError):
            verify_report(candidate)
    candidate = expected_report()
    candidate["findings"][1]["evidence_ids"] = ["P-B"]
    with pytest.raises(ValueError):
        verify_report(candidate)
    candidate = expected_report()
    candidate["findings"].append(candidate["findings"][0])
    with pytest.raises(ValueError):
        verify_report(candidate)


def test_verifier_rejects_invalid_source_rows_and_boolean_money():
    source = get_snapshot()
    source["payments"][0]["order_id"] = "unknown"
    with pytest.raises(ValueError):
        verify_report(expected_report(), source)
    candidate = expected_report()
    candidate["difference_cents"] = True
    with pytest.raises(ValidationError):
        verify_report(candidate)


def test_idempotency_is_atomic_and_rejects_reconfigured_replay(tmp_path):
    path = tmp_path / "runs.db"
    Store(path)
    request = RunRequest(idempotency_key="same-request", mode="scripted")
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        results = list(pool.map(lambda _: Store(path).create_run(request), range(8)))
    assert sum(created for _, created in results) == 1
    assert len({run.id for run, _ in results}) == 1
    with pytest.raises(ValueError, match="different run"):
        Store(path).create_run(
            RunRequest(idempotency_key="same-request", scenario="timeout_once", mode="scripted")
        )


def test_restart_keeps_attempts_and_fault_count(tmp_path):
    store, run_id, tools = setup_run(tmp_path, "timeout_once")
    first = tools.call("read_payments", {})
    assert first["error"]["code"] == "upstream_timeout"
    another_process = ToolService(Store(tmp_path / "runs.db"), run_id)
    assert another_process.call("read_payments", {"snapshot_id": "synthetic-day-001"})["ok"]
    assert store.get_run(run_id).fault_count == 1
    assert store.get_run(run_id).tool_calls == 2
    assert not another_process.call("read_payments", {})["ok"]
    assert store.get_run(run_id).status == "halted"


def test_persistent_outage_halts_after_two_attempts(tmp_path):
    store, run_id, tools = setup_run(tmp_path, "persistent_timeout")
    assert tools.call("read_payments", {})["error"]["retryable"]
    assert not tools.call("read_payments", {})["error"]["retryable"]
    assert store.get_run(run_id).status == "halted"
    assert store.get_run(run_id).fault_count == 2
    assert not tools.call("read_orders", {})["ok"]
    assert store.get_run(run_id).tool_calls == 2


def test_truncation_recovers_without_mutating_source(tmp_path):
    store, run_id, tools = setup_run(tmp_path, "truncated_once")
    first = tools.call("read_payments", {})
    assert first["error"]["code"] == "truncated_response"
    assert first["raw_response"].endswith("[")
    assert tools.call("read_payments", {})["total_received_cents"] == 55000
    assert store.get_run(run_id).fault_count == 1


def test_plausible_summary_corruption_is_independently_checkable(tmp_path):
    _, _, tools = setup_run(tmp_path, "wrong_total_once")
    summary = tools.call("read_payments", {})
    raw = tools.call("read_payment_rows", {})
    assert summary["ok"]
    assert summary["total_received_cents"] == 60000
    assert sum(row["amount_cents"] for row in raw["payments"]) == 55000
    assert reconcile(get_snapshot()) == expected_report()


def test_recovery_requires_observed_tools_and_exact_report(tmp_path):
    store, run_id, tools = setup_run(tmp_path, "timeout_once")
    with pytest.raises(ValueError, match="Required"):
        tools.verify_report(expected_report())
    tools.call("read_payments", {})
    for name in ("read_orders", "read_payments", "read_refunds", "read_payment_rows"):
        assert tools.call(name, {})["ok"]
    assert tools.verify_report(expected_report()) == expected_report()
    assert store.events(run_id)[-1]["kind"] == "report_verified"


def test_wall_clock_and_total_tool_budgets(tmp_path):
    store, run_id, tools = setup_run(tmp_path, max_calls=1)
    assert tools.call("read_orders", {})["ok"]
    assert tools.call("read_refunds", {})["error"]["code"] == "run_halted"
    assert store.get_run(run_id).tool_calls == 1
    other = tmp_path / "other"
    store, run_id, tools = setup_run(other)
    old = (datetime.now(UTC) - timedelta(seconds=181)).isoformat()
    store.update_run(run_id, started_at=old)
    assert not tools.call("read_orders", {})["ok"]
    assert store.get_run(run_id).status == "halted"


def test_worker_restart_is_an_explicit_halt_not_fake_resume(tmp_path):
    store, run_id, tools = setup_run(tmp_path)
    tools.call("read_orders", {})
    assert store.recover_interrupted() == 1
    assert store.get_run(run_id).status == "halted"
    assert store.get_run(run_id).tool_calls == 1
    assert store.recover_interrupted() == 0
    with pytest.raises(ValueError, match="Terminal"):
        store.update_run(run_id, status="completed")


def test_forbidden_tool_and_arguments_never_execute(tmp_path):
    store, run_id, tools = setup_run(tmp_path)
    assert tools.call("execute_refund", {})["error"]["code"] == "tool_forbidden"
    assert tools.call("read_orders", {"shell": "anything"})["error"]["code"] == "invalid_arguments"
    assert tools.call("inspect_order", {"order_id": "B"})["order"]["id"] == "O-B"
    assert store.get_run(run_id).tool_calls == 3


def test_increments_are_atomic_under_parallel_tool_calls(tmp_path):
    store, run_id, _ = setup_run(tmp_path)
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        results = list(
            pool.map(
                lambda _: ToolService(Store(tmp_path / "runs.db"), run_id).call("read_orders", {}),
                range(8),
            )
        )
    assert sum(bool(result["ok"]) for result in results) <= 2
    assert store.get_run(run_id).tool_calls == 2
    assert store.get_run(run_id).status == "halted"
    event_ids = [event["id"] for event in store.events(run_id)]
    assert event_ids == sorted(set(event_ids))
