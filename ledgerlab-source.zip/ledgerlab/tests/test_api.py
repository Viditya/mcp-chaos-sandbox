"""API behavior: authentication, replay safety, suite admission, and persisted evidence."""

import asyncio

import pytest
from fastapi.testclient import TestClient

from chaos_reconcile.api import create_app
from chaos_reconcile.models import RunRequest

TOKEN = "local-test-dashboard-token"
AUTH = {"Authorization": f"Bearer {TOKEN}"}


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("LEDGERLAB_RUNTIME", str(tmp_path / "runtime"))
    monkeypatch.setattr("chaos_reconcile.api.shutil.which", lambda _: None)
    return create_app(db_path=tmp_path / "api.sqlite3", token=TOKEN)


def test_health_public_but_run_data_requires_auth(app):
    client = TestClient(app)
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["auth_required"] is True
    assert health.json()["codex_available"] is False
    for path in (
        "/api/runs",
        "/api/scenarios",
        "/api/settings",
        "/api/runs/missing/events",
        "/api/runs/missing/export",
    ):
        assert client.get(path).status_code == 401
    assert client.get("/api/runs", headers=AUTH).json() == []
    assert client.get("/api/runs/missing", headers=AUTH).status_code == 404


def test_session_cookie_login_logout_and_cross_origin_writes(app):
    client = TestClient(app)
    assert client.post("/api/session", json={"token": "wrong"}).status_code == 401
    login = client.post("/api/session", json={"token": TOKEN})
    assert login.status_code == 200
    cookie = login.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=strict" in cookie
    assert client.get("/api/runs").status_code == 200
    blocked = client.post(
        "/api/runs",
        json={"mode": "scripted", "idempotency_key": "cross-origin-test"},
        headers={"Origin": "https://untrusted.example"},
    )
    assert blocked.status_code == 403
    allowed = client.post(
        "/api/runs",
        json={"mode": "scripted", "idempotency_key": "same-origin-test"},
        headers={"Origin": "http://testserver"},
    )
    assert allowed.status_code == 202
    assert client.delete("/api/session").status_code == 200
    assert client.get("/api/runs").status_code == 401


def test_secure_cookie_and_unconfigured_server(tmp_path, monkeypatch):
    monkeypatch.setenv("LEDGERLAB_RUNTIME", str(tmp_path / "runtime"))
    monkeypatch.setenv("CHAOS_COOKIE_SECURE", "1")
    configured = TestClient(
        create_app(tmp_path / "secure.sqlite3", token=TOKEN), base_url="https://testserver"
    )
    response = configured.post("/api/session", json={"token": TOKEN})
    assert "secure" in response.headers["set-cookie"].lower()
    assert configured.get("/api/runs").status_code == 200
    unconfigured = TestClient(create_app(tmp_path / "unconfigured.sqlite3", token=""))
    assert unconfigured.get("/api/runs", headers=AUTH).status_code == 503
    assert unconfigured.post("/api/session", json={"token": TOKEN}).status_code == 401


def test_same_idempotency_key_does_not_queue_duplicate_work(app):
    client = TestClient(app)
    body = {
        "scenario": "timeout_once",
        "mode": "scripted",
        "idempotency_key": "request-replay-test",
    }
    first = client.post("/api/runs", json=body, headers=AUTH)
    second = client.post("/api/runs", json=body, headers=AUTH)
    assert first.status_code == second.status_code == 202
    assert first.json()["id"] == second.json()["id"]
    assert app.state.worker.queue.qsize() == 1
    assert len(client.get("/api/runs", headers=AUTH).json()) == 1
    mismatch = client.post("/api/runs", json=body | {"scenario": "clean"}, headers=AUTH)
    assert mismatch.status_code == 409
    assert app.state.worker.queue.qsize() == 1


def test_suite_replay_and_export_keep_actual_events(app):
    client = TestClient(app)
    body = {"mode": "scripted", "idempotency_key": "all-scenarios-test"}
    first = client.post("/api/suite", json=body, headers=AUTH)
    second = client.post("/api/suite", json=body, headers=AUTH)
    assert first.status_code == second.status_code == 202
    first_ids = {run["id"] for run in first.json()["runs"]}
    assert len(first_ids) == 5
    assert first_ids == {run["id"] for run in second.json()["runs"]}
    assert app.state.worker.queue.qsize() == 5
    run_id = first.json()["runs"][0]["id"]
    app.state.store.add_event(
        run_id, "integration_marker", "Actual persisted event", {"evidence": 1}
    )
    events = client.get(f"/api/runs/{run_id}/events", headers=AUTH).json()
    incremental = client.get(
        f"/api/runs/{run_id}/events?after={events[0]['id']}", headers=AUTH
    ).json()
    assert len(incremental) == 1 and incremental[0]["kind"] == "integration_marker"
    exported = client.get(f"/api/runs/{run_id}/export", headers=AUTH)
    assert exported.status_code == 200
    assert exported.json() == {
        "run": app.state.store.get_run(run_id).model_dump(),
        "events": events,
    }
    assert "attachment" in exported.headers["content-disposition"]


def test_codex_unavailable_never_silently_falls_back_to_scripted(app):
    client = TestClient(app)
    response = client.post(
        "/api/runs", json={"mode": "codex", "idempotency_key": "no-model-available"}, headers=AUTH
    )
    assert response.status_code == 409
    assert app.state.store.list_runs() == []


def test_suite_capacity_is_checked_before_any_runs_are_created(tmp_path, monkeypatch):
    monkeypatch.setenv("LEDGERLAB_RUNTIME", str(tmp_path / "runtime"))
    monkeypatch.setenv("LEDGERLAB_MAX_CODEX_RUNS", "4")
    monkeypatch.setattr("chaos_reconcile.api.shutil.which", lambda _: "/fake/codex")
    app = create_app(tmp_path / "capacity.sqlite3", token=TOKEN)
    client = TestClient(app)
    denied = client.post(
        "/api/suite", json={"mode": "codex", "idempotency_key": "capacity-check-test"}, headers=AUTH
    )
    assert denied.status_code == 429
    assert app.state.store.list_runs() == []
    assert app.state.worker.queue.qsize() == 0


def test_suite_configuration_conflict_does_not_create_partial_work(tmp_path, monkeypatch):
    monkeypatch.setenv("LEDGERLAB_RUNTIME", str(tmp_path / "runtime"))
    monkeypatch.setattr("chaos_reconcile.api.shutil.which", lambda _: "/fake/codex")
    app = create_app(tmp_path / "conflict.sqlite3", token=TOKEN)
    original, _ = app.state.store.create_run(
        RunRequest(
            mode="scripted", scenario="timeout_once", idempotency_key="conflict-test:timeout_once"
        )
    )
    client = TestClient(app)
    denied = client.post(
        "/api/suite", json={"mode": "codex", "idempotency_key": "conflict-test"}, headers=AUTH
    )
    assert denied.status_code == 409
    assert [run.id for run in app.state.store.list_runs()] == [original.id]
    assert app.state.worker.queue.qsize() == 0


def test_startup_marks_interrupted_run_halted_without_resetting_evidence(app, monkeypatch):
    run, _ = app.state.store.create_run(
        RunRequest(mode="scripted", idempotency_key="interrupted-run")
    )
    app.state.store.claim_run(run.id)
    app.state.store.add_event(run.id, "checkpoint", "Persisted before interruption")

    async def idle_worker():
        await asyncio.Event().wait()

    monkeypatch.setattr(app.state.worker, "serve", idle_worker)
    with TestClient(app) as client:
        result = client.get(f"/api/runs/{run.id}", headers=AUTH).json()
        assert result["status"] == "halted"
        kinds = [
            event["kind"] for event in client.get(f"/api/runs/{run.id}/events", headers=AUTH).json()
        ]
        assert "checkpoint" in kinds and "run_halted" in kinds
