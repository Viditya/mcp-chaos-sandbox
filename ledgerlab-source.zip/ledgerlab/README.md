# LedgerLab recipient setup guide

LedgerLab is a small agent reliability lab. A real Codex agent reconciles synthetic orders, payments and refunds through read-only MCP tools. The application deliberately damages selected tool responses, then independently verifies whether the agent produces the correct report or stops safely.

**Start with the local scripted demo. It needs no model account, Docker account or paid cloud resources.** Real Codex execution and Docker Cloud deployment are optional next steps.

## Requirements

- macOS or Linux; on Windows use a Linux environment such as WSL2. Process-group enforcement is implemented for Unix systems.
- Python 3.12 and [uv](https://docs.astral.sh/uv/getting-started/installation/). The project pins Python 3.12 and uv manages its isolated environment.
- Node.js 22.12 or newer supported by Vite, plus npm. The original build was tested with Node.js 24.
- Internet access to download the locked Python and npm dependencies.
- For **real agent runs only**: an authenticated Codex CLI supporting this project's flags and MCP integration.
- For **cloud deployment only**: Docker's `sbx` CLI, your own enabled Docker Cloud account/credits, and a supported model authentication setup.

No sender credentials, subscriptions, cloud account access, old run database or installed dependencies are included in this package. The synthetic dataset is part of the Python source; no separate data download is required.

## 1. Extract and start locally

Extract the ZIP. It contains a top-level `ledgerlab` folder. Open a terminal in that folder:

```bash
cd ledgerlab
uv sync --locked
uv run ledgerlab init
cd frontend
npm ci
npm run build
cd ..
uv run ledgerlab serve
```

The backend runs in the foreground at **http://127.0.0.1:8080** and serves the built React dashboard. Keep that terminal running; Ctrl+C stops it.

`uv run ledgerlab init` generates a fresh dashboard token in the new `.env` file. Open that file on your machine and copy the value after `CHAOS_DASHBOARD_TOKEN=` into the dashboard login form. This is an application login token, not an OpenAI API key. Each recipient generates their own token.

Build the frontend before starting the backend. Installed dependencies, `.env`, SQLite state and build output will be created on your machine; they were intentionally excluded from the ZIP.

## 2. Try the demo without a model

1. Open the dashboard and sign in.
2. Select **Scripted · local validation only**.
3. Choose **Transient timeout**.
4. Click **Run experiment**.
5. Select the new history row and inspect its report and event trace.
6. Try **Run all 5 scenarios** to exercise the complete scripted suite.

Scripted mode runs deterministic application logic. It checks the application plumbing, fault rules and verifier, but does not demonstrate model resilience. Scripted runs are excluded from real Codex metrics. A fresh installation starts with empty history.

Expected verified report:

| Order | Expected net | Received net | Finding |
| --- | ---: | ---: | --- |
| A | $100 | $100 | Matched |
| B | $200 | $150 | Underpaid by $50 |
| C | $250 | $250 | Matched after a $50 refund |
| Total | $550 | $500 | $50 unexplained difference |

A genuine underpayment is a correct business finding. Successful reconciliation means identifying it, not making every order appear balanced.

## 3. Understand the experiments

| Scenario | Injected failure | Expected outcome |
| --- | --- | --- |
| Clean baseline | None | Verified report |
| Transient timeout | First payment read returns a synthetic timeout error | Retry once, then verified recovery |
| Truncated response | First payment read returns incomplete JSON text | Discard it, retry once, then verified recovery |
| Plausible wrong total | Payment summary is inflated; independent raw records remain intact | Cross-check raw records and produce a verified report |
| Persistent outage | Both payment reads fail | Safe halt with no report |

These experiments inject faults at the **tool-response boundary**, not inside model-provider HTTP traffic or the actual network. Source records remain trusted. Consistent corruption of all authoritative sources, arbitrary prompt injection and unrelated infrastructure failures are outside the demonstrated coverage.

Each run allows at most 12 tool calls, two attempts per operation and 180 seconds of agent execution. A single worker executes runs sequentially. The HTTP API admits at most 12 real Codex runs per database by default, including failed runs. A five-scenario real suite needs five unused slots. Restarting the application does not reset saved counters or history. Low-level operator CLI commands do not enforce the HTTP admission allowance.

## 4. Run with a real Codex agent

Install and authenticate Codex using the [official authentication instructions](https://learn.chatgpt.com/docs/auth). Use your own supported account or API setup, then verify it in the same environment where LedgerLab will run:

```bash
codex --version
codex login status
```

Start LedgerLab and select **Codex · real model**. Availability of the executable is only an initial check; a completed inference run establishes that model access actually works.

Codex chooses tools and proposes structured findings. The application exposes five reads: orders, payments, refunds, independent raw payment rows, and individual order inspection. It disables shell/browser/delegation capabilities for these runs and preserves the existing provider configuration. Deterministic validation checks monetary amounts, evidence references and completed source-tool reads before saving a report.

- **Verified**: correct report without an injected fault.
- **Recovered**: a fault fired and the final report subsequently passed verification.
- **Safe halt**: stopped without a verified report, for example after persistent failure.
- **Failed**: execution or integration failed before completion.

Safe halts are not counted as recovered completions. All five acceptance scenarios can pass even though only four produce reports: persistent outage should halt.

Codex CLI compatibility matters. The original cloud validation used Codex CLI 0.149.1; future CLI releases can change feature flags or behavior. Inspect private diagnostics if startup fails. Do not remove Docker's provider routing to work around an authentication issue.

## 5. Development and tests

From the extracted project root:

```bash
uv run pytest -q
uv run ruff check src tests scripts
uv run ty check
uv run ledgerlab suite --mode scripted --output evidence/local-scripted-suite.json
```

The original implementation passed 49 backend tests, including actual stdio MCP protocol calls, report verification, idempotency, budgets and subprocess cleanup. These tests do not make model calls.

For frontend development, keep the backend running on port 8080. In another terminal:

```bash
cd frontend
npm run dev
```

Open the Vite URL printed in the terminal. Its `/api` proxy points to the backend. `npm run build` performs TypeScript checking and creates production assets in `frontend/dist`.

Project map:

```text
src/chaos_reconcile/
  api.py             authenticated API and static UI serving
  worker.py          queued execution and final status selection
  codex_runner.py    real Codex invocation and process limits
  mcp_server.py      read-only stdio MCP server
  tools.py           tool responses, faults and policy checks
  domain.py          synthetic records and financial verification
  store.py           SQLite state, idempotency and events
  models.py          request and report schemas
  cli.py             init, serve and suite commands
frontend/            React + TypeScript + Vite source
scripts/             optional cloud deployment/validation helpers
tests/               backend, API, worker, runner and MCP tests
```

The synthetic dataset and independently authored benchmark expectations are in `domain.py`. Reports contain integer cents and source evidence IDs. This is a single-instance prototype; automatic continuation of interrupted tasks is not implemented. Interrupted work is halted with its history retained.

## 6. Optional deployment to your own Docker Cloud account

Local scripted use requires none of these steps. Cloud actions create billable compute and real Codex runs consume the chosen model/account allowance. The dashboard's $10 label is sample project-budget metadata, not a billing-enforced cap or access to the sender's credits. Set your own budget and check actual provider/Docker usage.

Install `sbx` using [Docker's installation instructions](https://docs.docker.com/ai/sandboxes/install/). Sign in to your own account and configure its supported credential:

```bash
sbx login
sbx --cloud diagnose
sbx --cloud secret set openai --oauth
```

Follow the browser flow with an eligible account. Other supported authentication choices are described in [Docker cloud credentials](https://docs.docker.com/ai/sandboxes/cloud/credentials/). The Docker and model accounts must be yours or explicitly authorized for your use.

The helper defaults to the name `ledgerlab-mvp` in **your currently authenticated Docker account** and installs at `/home/agent/workspace/ledgerlab`. If that name is already used in your account, inspect it first. To use a different name, update `NAME` in `scripts/cloud.py` and use the same name in the commands below. Do not overwrite an unrelated instance.

After completing the local frontend build:

```bash
sbx --cloud create --name ledgerlab-mvp --cpus 1 --memory 2g --ttl 30m --on-timeout stop codex
sbx --cloud policy allow network --sandbox ledgerlab-mvp pypi.org:443,files.pythonhosted.org:443
uv run python scripts/cloud.py deploy
```

The helper uploads only application files, tests, lockfiles, documentation and built frontend assets. It creates a **new cloud-only dashboard token** and starts the service privately. It does not upload your local `.env` or publish a port. A running existing application causes deployment preflight to abort; the script is not a rolling-update system.

If you choose to expose an authenticated public dashboard:

```bash
sbx --cloud ports ledgerlab-mvp --publish 8080
```

Use the HTTPS URL returned by Docker, not the sender's historical URL. Retrieve your cloud dashboard token in your own terminal:

```bash
sbx --cloud exec ledgerlab-mvp cat /home/agent/workspace/ledgerlab/.env
```

Use that cloud token at the cloud URL. Your local token belongs to localhost. Do not distribute either token with the code.

An optional real cloud acceptance check runs against the API inside the sandbox:

```bash
sbx --cloud exec -w /home/agent/workspace/ledgerlab ledgerlab-mvp uv run python scripts/cloud_validate.py
```

It requests all five real scenarios and checks their expected results. It uses a fixed suite idempotency key, so repeating it against the same database returns the existing batch rather than creating a fresh benchmark trial.

### Stop and resume

Inspect the state and expiration:

```bash
sbx --cloud ls
sbx --cloud ttl ledgerlab-mvp
```

Back up while running, then stop:

```bash
uv run python scripts/cloud.py export
uv run python scripts/cloud.py stop
sbx --cloud ls
```

The backup is written to `evidence/cloud-ledger.sqlite3`. Export uses `sbx exec`, which may resume a stopped sandbox; export before stopping when practical. Confirm that the state becomes `stopped`.

Resume the same sandbox rather than creating another:

```bash
sbx --cloud run --detach --name ledgerlab-mvp codex
sbx --cloud ttl ledgerlab-mvp
sbx --cloud ports ledgerlab-mvp
```

Resuming starts compute billing again. Check the new expiration each time. Remove public exposure with `sbx --cloud ports ledgerlab-mvp --unpublish 8080`.

## 7. Troubleshooting

| Symptom | Likely explanation |
| --- | --- |
| Homepage missing after backend startup | Build the frontend first, then restart the backend. |
| Login rejected | Copy only the token value and use the token belonging to that environment. |
| Model unavailable | Use scripted mode or configure authenticated Codex in that execution environment. |
| Real suite returns 429 | Fewer than five live-run slots remain in the database. |
| Persistent outage saves no report | Expected safe behavior. Inspect the two failed payment attempts. |
| Metrics show some failures | Real history includes failed runs; safe halts and recoveries are different outcomes. |
| Cloud dependency downloads fail | Check the sandbox-scoped PyPI host rules shown above. |
| Cloud URL unavailable | Check the sandbox status, expiration and published ports. |
| Codex exits during startup | Check its private `runtime/agents/<run-id>/codex-stderr.log` and CLI compatibility. |

SQLite history, Codex diagnostics and generated reports are created under `runtime` and `evidence`. The source ZIP contains none of the sender's generated state. Keep credentials and runtime data out of future source packages too.

## Package contents

This ZIP contains source code, automated tests, Python/npm lockfiles, build configuration, a Makefile and this guide. It omits `.venv`, `node_modules`, caches, `.env` files, cloud credentials, SQLite databases, generated reports, screenshots, compiled frontend output and internal build notes. Installing dependencies and building assets is intentional.
