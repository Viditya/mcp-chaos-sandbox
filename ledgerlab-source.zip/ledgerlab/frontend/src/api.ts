export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}
export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    credentials: "same-origin",
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });
  if (!response.ok) {
    let message = `Request failed (${response.status}).`;
    try {
      const body = await response.json() as { detail?: unknown };
      if (typeof body.detail === "string") message = body.detail;
      else if (body.detail) message = JSON.stringify(body.detail);
    } catch { /* Keep the HTTP status if a proxy returns a non-JSON response. */ }
    throw new ApiError(response.status, message);
  }
  return response.json() as Promise<T>;
}
export function errorText(error: unknown): string {
  return error instanceof Error ? error.message : "Could not reach the service.";
}
