import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { api, ApiError, errorText } from "./api";
import type { Health, Mode, Report, Run, RunEvent, Scenario, Settings } from "./types";

const finished = (run: Run) => ["completed", "recovered", "halted", "failed"].includes(run.status);
const successful = (run: Run) => ["completed", "recovered"].includes(run.status);
const labels: Record<Run["status"], string> = {
  queued: "Queued", running: "Running", completed: "Verified", recovered: "Recovered", halted: "Safe halt", failed: "Failed",
};
const money = (cents: number, currency = "USD") => new Intl.NumberFormat("en-US", { style: "currency", currency }).format(cents / 100);
const time = (value: string) => new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
const shortId = (value: string) => value.slice(0, 8);
function duration(run: Run) {
  const seconds = Math.max(0, Math.round(((finished(run) ? new Date(run.updated_at).getTime() : Date.now()) - new Date(run.created_at).getTime()) / 1000));
  return seconds < 60 ? `${seconds}s` : `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
}
function Icon({ name, size = 18 }: { name: "play" | "arrow" | "download" | "check" | "shield" | "bolt" | "chart" | "refresh" | "lock" | "chevron"; size?: number }) {
  const paths: Record<string, ReactNode> = {
    play: <path d="m9 5 11 7-11 7V5Z" />,
    arrow: <><path d="M5 12h14m-5-5 5 5-5 5" /></>,
    download: <><path d="M12 3v12m-5-5 5 5 5-5M5 17v4h14v-4" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    shield: <><path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z" /><path d="m8 12 3 3 5-6" /></>,
    bolt: <path d="m13 2-9 12h7l-1 8 10-13h-7l1-7Z" />,
    chart: <><path d="M4 4v16h16M8 15v-4m5 4V7m5 8v-6" /></>,
    refresh: <><path d="M20 7v5h-5M4 17v-5h5" /><path d="M6 7a7 7 0 0 1 12-2l2 3M4 16l2 3a7 7 0 0 0 12-2" /></>,
    lock: <><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2" /></>,
    chevron: <path d="m9 5 7 7-7 7" />,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}
function Brand() {
  return <a className="brand" href="/" aria-label="LedgerLab home"><span className="brand-mark"><span /><span /><span /></span><span>Ledger<span className="brand-light">Lab</span></span></a>;
}
function Status({ run }: { run: Run }) {
  return <span className={`status status-${run.status}`}><span className="status-dot" />{labels[run.status]}</span>;
}
function Metric({ label, value, note, icon, accent }: { label: string; value: ReactNode; note: string; icon: "chart" | "check" | "refresh" | "shield"; accent?: string }) {
  return <div className={`metric ${accent ?? ""}`}><div className="metric-heading">{label}<Icon name={icon} size={17} /></div><div className="metric-value">{value}</div><p>{note}</p></div>;
}
function VerifiedReport({ report }: { report: Report }) {
  return <div className="report">
    <div className="section-heading"><div><span className="eyebrow">RESULT</span><h3>Verified reconciliation</h3></div><span className="verified-label"><Icon name="check" size={15} />Checked against source records</span></div>
    <div className="report-totals"><div><span>Expected net</span><strong>{money(report.expected_net_cents, report.currency)}</strong></div><div><span>Received net</span><strong>{money(report.received_net_cents, report.currency)}</strong></div><div className={report.difference_cents !== 0 ? "difference" : ""}><span>Unexplained difference</span><strong>{money(report.difference_cents, report.currency)}</strong></div></div>
    <div className="table-scroll"><table className="findings-table"><thead><tr><th>Order</th><th>Expected</th><th>Received</th><th>Difference</th><th>Finding / evidence</th></tr></thead><tbody>{report.findings.map((finding) => <tr key={finding.order_id}><td><span className="order-id">{finding.order_id}</span></td><td>{money(finding.expected_net_cents, report.currency)}</td><td>{money(finding.received_net_cents, report.currency)}</td><td className={finding.difference_cents ? "text-orange" : "muted"}>{money(finding.difference_cents, report.currency)}</td><td><span className={finding.difference_cents ? "finding-exception" : "finding-matched"}>{finding.status.replaceAll("_", " ")}</span><small className="evidence">{finding.evidence_ids.join(" · ") || "No evidence references"}</small></td></tr>)}</tbody></table></div>
    <p className="report-footnote">A genuine underpayment is a business finding. Detecting it correctly counts as successful task completion.</p>
  </div>;
}
function EventLog({ events, run }: { events: RunEvent[]; run: Run }) {
  const bottom = useRef<HTMLDivElement>(null);
  const [following, setFollowing] = useState(true);
  useEffect(() => { if (following) { const container = bottom.current?.parentElement; container?.scrollTo({ top: container.scrollHeight, behavior: "smooth" }); } }, [events.length, following]);
  return <div className="event-panel"><div className="section-heading"><div><span className="eyebrow">EXECUTION TRACE</span><h3>What actually happened <span className="count-pill">{events.length}</span></h3></div><label className="follow-control"><input type="checkbox" checked={following} onChange={(e) => setFollowing(e.target.checked)} />Follow</label></div>
    <div className="event-log" role="log" aria-label="Persisted execution events" aria-live="polite" aria-relevant="additions" tabIndex={0}>
      {events.length === 0 ? <div className="empty-trace"><Icon name="chart" size={24} /><p>{run.status === "queued" ? "Waiting for the worker. Events will appear when execution starts." : "No persisted events yet."}</p></div> : events.map((event) => {
        const kind = /fault|corrupt|timeout|truncat/i.test(event.kind) ? "fault" : /halt|budget|fail|reject/i.test(event.kind) ? "halt" : /verif|complete|recover|success/i.test(event.kind) ? "success" : "tool";
        return <div className={`event event-${kind}`} key={event.id}><div className="event-rail"><span /></div><div className="event-body"><div className="event-meta"><span>{event.kind.replaceAll("_", " ")}</span><time dateTime={event.created_at}>{time(event.created_at)}</time></div><p>{event.message}</p>{event.data && Object.keys(event.data).length > 0 && <details><summary>Inspect event data</summary><pre>{JSON.stringify(event.data, null, 2)}</pre></details>}</div></div>;
      })}<div ref={bottom} />
    </div><div className="trace-footer"><span className={`connection-dot ${finished(run) ? "complete" : ""}`} />{finished(run) ? "Run finished · events preserved" : "Polling persisted events every second"}<span>Run {shortId(run.id)}</span></div>
  </div>;
}

export default function App() {
  const [health, setHealth] = useState<Health | null>(null);
  const [authorized, setAuthorized] = useState<boolean | null>(null);
  const [token, setToken] = useState("");
  const [loggingIn, setLoggingIn] = useState(false);
  const [runs, setRuns] = useState<Run[]>([]);
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedRun, setSelectedRun] = useState<Run | null>(null);
  const [events, setEvents] = useState<RunEvent[]>([]);
  const [scenarioId, setScenarioId] = useState("timeout_once");
  const [mode, setMode] = useState<Mode>("codex");
  const [filter, setFilter] = useState<"all" | Mode>("all");
  const [busy, setBusy] = useState(false);
  const [networkError, setNetworkError] = useState("");
  const [actionError, setActionError] = useState("");
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const pendingAction = useRef<{ intent: string; key: string } | null>(null);

  const onError = useCallback((error: unknown) => {
    if (error instanceof ApiError && error.status === 401) { setAuthorized(false); setToken(""); }
    else setNetworkError(errorText(error));
  }, []);
  const refresh = useCallback(async () => {
    try {
      const list = await api<Run[]>("/api/runs");
      setRuns(list);
      setSelectedId((current) => current ?? list[0]?.id ?? null);
      setLastSync(new Date());
      setNetworkError("");
    } catch (error) { onError(error); }
  }, [onError]);
  const boot = useCallback(async () => {
    try {
      const status = await api<Health>("/api/health");
      setHealth(status);
      const [list, availableScenarios, configuration] = await Promise.all([
        api<Run[]>("/api/runs"), api<Scenario[]>("/api/scenarios"), api<Settings>("/api/settings"),
      ]);
      setRuns(list); setScenarios(availableScenarios); setSettings(configuration);
      setSelectedId((current) => current ?? list[0]?.id ?? null);
      setAuthorized(true); setNetworkError(""); setLastSync(new Date());
    } catch (error) { onError(error); }
  }, [onError]);
  useEffect(() => { void boot(); }, [boot]);
  useEffect(() => {
    if (!authorized) return;
    const interval = window.setInterval(() => void refresh(), 1500);
    return () => window.clearInterval(interval);
  }, [authorized, refresh]);
  useEffect(() => {
    setEvents([]); setSelectedRun(null);
    if (!authorized || !selectedId) return;
    const controller = new AbortController();
    let eventCursor = 0;
    let inFlight = false;
    const poll = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const [run, nextEvents] = await Promise.all([
          api<Run>(`/api/runs/${selectedId}`, { signal: controller.signal }),
          api<RunEvent[]>(`/api/runs/${selectedId}/events?after=${eventCursor}`, { signal: controller.signal }),
        ]);
        if (controller.signal.aborted) return;
        setSelectedRun(run);
        if (nextEvents.length) {
          eventCursor = Math.max(eventCursor, ...nextEvents.map((event) => event.id));
          setEvents((previous) => {
            const byId = new Map(previous.map((event) => [event.id, event]));
            nextEvents.forEach((event) => byId.set(event.id, event));
            return [...byId.values()].sort((a, b) => a.id - b.id);
          });
        }
      } catch (error) { if (!controller.signal.aborted) onError(error); }
      finally { inFlight = false; }
    };
    void poll();
    const interval = window.setInterval(() => void poll(), 1000);
    return () => { controller.abort(); window.clearInterval(interval); };
  }, [selectedId, authorized, onError]);

  async function login(event: FormEvent) {
    event.preventDefault(); setLoggingIn(true); setActionError("");
    try { await api("/api/session", { method: "POST", body: JSON.stringify({ token }) }); setToken(""); await boot(); }
    catch (error) { setActionError(errorText(error)); }
    finally { setLoggingIn(false); }
  }
  async function start(suite: boolean) {
    const intent = suite ? `suite:${mode}` : `${scenarioId}:${mode}`;
    if (pendingAction.current?.intent !== intent) pendingAction.current = { intent, key: crypto.randomUUID() };
    setBusy(true); setActionError("");
    try {
      const body = { mode, idempotency_key: pendingAction.current.key, ...(suite ? {} : { scenario: scenarioId }) };
      const result = await api<Run | { runs: Run[] }>(suite ? "/api/suite" : "/api/runs", { method: "POST", body: JSON.stringify(body) });
      const run = "runs" in result ? result.runs[0] : result;
      if (run) { setSelectedId(run.id); setFilter("all"); }
      pendingAction.current = null;
      await refresh();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) onError(error);
      setActionError(errorText(error));
    } finally { setBusy(false); }
  }

  const realRuns = runs.filter((run) => run.mode === "codex");
  const endedReal = realRuns.filter(finished);
  const verified = endedReal.filter(successful);
  const faultedReal = endedReal.filter((run) => run.fault_count > 0);
  const recovered = faultedReal.filter((run) => run.status === "recovered");
  const halted = endedReal.filter((run) => run.status === "halted");
  const selectedScenario = scenarios.find((scenario) => scenario.id === scenarioId);
  const visibleRuns = runs.filter((run) => filter === "all" || run.mode === filter);
  const activeRun = selectedRun ?? runs.find((run) => run.id === selectedId) ?? null;
  const codexAvailable = settings?.codex_available ?? health?.codex_available ?? false;
  const canStart = !busy && (mode === "scripted" || codexAvailable) && scenarios.length > 0;

  return <div className="app-shell">
    <header className="topbar"><Brand /><div className="topbar-middle"><span className="nav-active">Reconciliation lab</span><span className="topbar-divider" />MVP / Synthetic data</div><div className="environment"><span className={`connection-dot ${authorized ? "" : "offline"}`} />{health?.environment?.replaceAll("_", " ") || "Connecting"}</div></header>
    {authorized === false ? <main className="login-wrap"><section className="login-card"><span className="login-icon"><Icon name="lock" size={25} /></span><span className="eyebrow">PRIVATE WORKSPACE</span><h1>Open your lab.</h1><p>Enter the dashboard access token configured for this deployment. Your model credentials stay in the sandbox secret store.</p><form onSubmit={(event) => void login(event)}><label htmlFor="dashboard-token">Dashboard access token</label><input id="dashboard-token" type="password" value={token} onChange={(event) => setToken(event.target.value)} autoComplete="current-password" required autoFocus placeholder="Enter access token" /><button className="button button-primary" disabled={loggingIn || !token}>{loggingIn ? "Opening workspace…" : "Open workspace"}<Icon name="arrow" /></button></form>{actionError && <p className="error-message" role="alert">{actionError}</p>}<div className="login-note"><Icon name="shield" size={15} />Session uses an HttpOnly cookie. No token is saved in browser storage.</div></section></main> : authorized === null ? <main className="loading-wrap"><div className="loading-mark" /><h1>Connecting to LedgerLab</h1><p>{networkError || "Checking service and loading persisted runs…"}</p>{networkError && <button className="button button-secondary" onClick={() => void boot()}><Icon name="refresh" />Retry connection</button>}</main> : <main className="workspace">
      <section className="page-heading"><div><div className="eyebrow"><span className="small-rule" />AGENT RESILIENCE / EXPERIMENT WORKSPACE</div><h1>Reconciliation lab<span>.</span></h1><p>Break a tool call. Observe the recovery. Verify the result.</p></div><div className="scope-badge"><Icon name="shield" size={22} /><div><strong>Read-only by design</strong><span>No payment or refund actions</span></div></div></section>
      {(networkError || actionError) && <div className="error-banner" role="alert"><strong>{networkError ? "Connection issue" : "Could not start run"}</strong><span>{actionError || networkError}</span><button onClick={() => { setActionError(""); void refresh(); }} aria-label="Dismiss message and retry refresh">Retry</button></div>}
      <section className="metrics" aria-label="Real Codex run metrics"><Metric label="Real agent runs" value={realRuns.length} note={`${realRuns.filter((run) => !finished(run)).length} active or queued · scripted runs excluded`} icon="chart" /><Metric label="Verified completion" value={<>{verified.length}<span> / {endedReal.length}</span></>} note="Correct results / finished real runs" icon="check" accent="metric-teal" /><Metric label="Recovered after fault" value={<>{recovered.length}<span> / {faultedReal.length}</span></>} note="Verified recovery / finished faulted runs" icon="refresh" /><Metric label="Safely halted" value={halted.length} note="Stopped within limits · not counted as recovered" icon="shield" accent="metric-orange" /></section>
      <div className="workbench-grid">
        <aside className="setup-column">
          <section className="panel setup-panel"><div className="section-heading"><div><span className="eyebrow">01 / CONFIGURE</span><h2>Run an experiment</h2></div><span className="panel-icon"><Icon name="bolt" /></span></div>
            <label className="field-label" htmlFor="execution-mode">Execution engine</label><select id="execution-mode" value={mode} onChange={(event) => setMode(event.target.value as Mode)}><option value="codex">Codex · real model</option><option value="scripted">Scripted · local validation only</option></select>
            <div className={`engine-note ${mode === "scripted" ? "warning-note" : ""}`}><span className={`connection-dot ${mode === "scripted" || !codexAvailable ? "offline" : ""}`} />{mode === "scripted" ? "Scripted simulation. Excluded from real-agent metrics." : codexAvailable ? "Codex executable available. Each run validates inference." : "Codex unavailable in this runtime. Real runs are disabled."}</div>
            <label className="field-label" htmlFor="fault-scenario">Fault scenario</label><select id="fault-scenario" value={scenarioId} onChange={(event) => setScenarioId(event.target.value)}>{scenarios.map((scenario) => <option key={scenario.id} value={scenario.id}>{scenario.label}</option>)}</select>
            <div className="scenario-explainer"><p>{selectedScenario?.description || "Loading fault scenarios…"}</p><div><span>EXPECTED BEHAVIOR</span><p>{selectedScenario?.expected_outcome || "—"}</p></div></div>
            <button className="button button-primary run-button" onClick={() => void start(false)} disabled={!canStart}><Icon name="play" size={17} />{busy ? "Queueing…" : "Run experiment"}<span>01</span></button><button className="button button-secondary suite-button" onClick={() => void start(true)} disabled={!canStart}>Run all {scenarios.length || 5} scenarios<Icon name="arrow" size={17} /></button>
            <p className="setup-footnote">Runs execute one at a time. Retrying a failed start request reuses its idempotency key.</p>
          </section>
          <section className="panel fixture-panel"><div className="section-heading"><div><span className="eyebrow">THE WORKLOAD</span><h2>A ledger with one exception</h2></div></div><p className="body-small">Three synthetic orders. One approved refund. One genuine underpayment to investigate.</p><div className="fixture-row"><span>Order A</span><span>Matched</span><strong>$100</strong></div><div className="fixture-row fixture-exception"><span>Order B</span><span>$50 underpaid</span><strong>$150</strong></div><div className="fixture-row"><span>Order C</span><span>After $50 refund</span><strong>$250</strong></div><div className="fixture-total"><span>Known expected net</span><strong>$550.00</strong></div><p className="fixture-note">Fixed source snapshot · USD · amounts stored as integer cents. The verifier checks records independently of tool summaries.</p></section>
          <section className="limits-panel"><span className="eyebrow">EXECUTION BOUNDARIES</span><dl><div><dt>Tool calls</dt><dd>≤ {settings?.limits.max_tool_calls ?? "—"} / run</dd></div><div><dt>Attempts per operation</dt><dd>≤ {settings?.limits.max_attempts ?? "—"}</dd></div><div><dt>Run deadline</dt><dd>{settings?.limits.timeout_seconds ?? "—"} seconds</dd></div><div><dt>Authorized project budget</dt><dd>{money((settings?.budget.authorized_usd ?? 10) * 100)}</dd></div></dl><p>{settings?.budget.note || "Cloud compute and model usage are separate. No live dollar-spend reading is available."}</p><p className="boundary-copy">{settings?.fault_boundary || "Fault injection is limited to read-only reconciliation tool responses."}</p></section>
        </aside>
        <div className="results-column">
          <section className="panel history-panel"><div className="section-heading"><div><span className="eyebrow">02 / OBSERVE</span><h2>Experiment history <span className="count-pill">{runs.length}</span></h2></div><div className="segmented" aria-label="Filter run history">{(["all", "codex", "scripted"] as const).map((item) => <button key={item} onClick={() => setFilter(item)} className={filter === item ? "selected" : ""} aria-pressed={filter === item}>{item === "all" ? "All" : item === "codex" ? "Real agent" : "Scripted"}</button>)}</div></div>
            {visibleRuns.length === 0 ? <div className="empty-history"><span className="empty-icon"><Icon name="chart" size={28} /></span><h3>{runs.length ? "No runs in this view" : "Your first experiment starts here"}</h3><p>{runs.length ? "Choose another filter to view your experiments." : "Choose a failure scenario and run the agent. Its actual events and verified findings will appear here."}</p><span>NO SAMPLE RESULTS · NO ASSUMED RECOVERY</span></div> : <div className="run-list" aria-label="Run history">{visibleRuns.map((run) => <button className={`run-row ${selectedId === run.id ? "active" : ""}`} key={run.id} onClick={() => setSelectedId(run.id)} aria-pressed={selectedId === run.id}><div className={`run-icon ${run.status}`}><Icon name={successful(run) ? "check" : run.status === "halted" ? "shield" : "bolt"} size={18} /></div><div className="run-description"><strong>{scenarios.find((scenario) => scenario.id === run.scenario)?.label ?? run.scenario.replaceAll("_", " ")}</strong><span><code>{shortId(run.id)}</code><span className={run.mode === "scripted" ? "scripted-label" : ""}>{run.mode === "codex" ? "Codex" : "Scripted"}</span>· {time(run.created_at)}</span></div><div className="run-outcome"><Status run={run} /><span>{run.tool_calls} calls · {run.fault_count} faults · {duration(run)}</span></div><Icon name="chevron" size={16} /></button>)}</div>}
          </section>
          {activeRun && <section className="panel selected-panel" aria-label="Selected experiment"><div className="selected-run-heading"><div><span className="eyebrow">SELECTED RUN / {shortId(activeRun.id)}</span><h2>{scenarios.find((scenario) => scenario.id === activeRun.scenario)?.label ?? activeRun.scenario.replaceAll("_", " ")}</h2></div><a className="button button-small button-secondary" href={`/api/runs/${activeRun.id}/export`} download={`ledgerlab-${activeRun.id}.json`}><Icon name="download" size={15} />Export</a></div><div className="run-summary"><Status run={activeRun} /><span>{activeRun.mode === "codex" ? "Real Codex execution" : "Scripted simulation · not a model run"}</span><span>{activeRun.tool_calls} tool calls</span><span>{activeRun.fault_count} faults injected</span></div>{activeRun.mode === "scripted" && <div className="simulation-banner">This run validates the local harness using scripted decisions. It does not demonstrate real model resilience.</div>}{activeRun.error && <div className="run-error"><Icon name="shield" size={18} /><div><strong>{activeRun.status === "halted" ? "Execution stopped safely" : "Run did not complete"}</strong><p>{activeRun.error}</p></div></div>}{activeRun.report && successful(activeRun) ? <VerifiedReport report={activeRun.report} /> : <div className="pending-report"><Icon name="shield" size={20} /><p>{finished(activeRun) ? "No verified result was produced. This run is not counted as successful recovery." : "The report appears only after source records and final findings pass verification."}</p></div>}<EventLog key={activeRun.id} events={events} run={activeRun} />{Object.keys(activeRun.model_usage).length > 0 && <details className="usage-details"><summary>Model usage recorded by the agent</summary><pre>{JSON.stringify(activeRun.model_usage, null, 2)}</pre></details>}</section>}
        </div>
      </div>
      <footer className="workspace-footer"><span><strong>LedgerLab</strong> / A controlled test of agent resilience</span><span><span className="connection-dot" />{lastSync ? `Last sync ${lastSync.toLocaleTimeString()}` : "Connecting"}</span></footer>
    </main>}
  </div>;
}
