export type Mode = "codex" | "scripted";
export type RunStatus = "queued" | "running" | "completed" | "recovered" | "halted" | "failed";
export interface Finding {
  order_id: string;
  expected_net_cents: number;
  received_net_cents: number;
  difference_cents: number;
  status: string;
  evidence_ids: string[];
}
export interface Report {
  currency: string;
  expected_net_cents: number;
  received_net_cents: number;
  difference_cents: number;
  findings: Finding[];
  [key: string]: unknown;
}
export interface Run {
  id: string;
  scenario: string;
  mode: Mode;
  status: RunStatus;
  created_at: string;
  updated_at: string;
  fault_count: number;
  tool_calls: number;
  model_usage: Record<string, unknown>;
  report: Report | null;
  error: string | null;
}
export interface RunEvent {
  id: number;
  run_id: string;
  kind: string;
  message: string;
  data: Record<string, unknown> | null;
  created_at: string;
}
export interface Scenario {
  id: string;
  label: string;
  description: string;
  expected_outcome: string;
}
export interface Settings {
  codex_available: boolean;
  environment: string;
  limits: { max_tool_calls: number; max_attempts: number; timeout_seconds: number };
  budget: { authorized_usd: number; cloud_rate_usd_per_hour: number | null; note: string };
  fault_boundary: string;
}
export interface Health {
  status: string;
  codex_available: boolean;
  auth_required: boolean;
  environment: string;
}
